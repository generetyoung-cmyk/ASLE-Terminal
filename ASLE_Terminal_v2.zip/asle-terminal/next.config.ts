import type { NextConfig } from "next"

const config: NextConfig = {
  reactStrictMode: true,

  // Allow IPFS and GeckoTerminal image domains
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "**.ipfs.nftstorage.link" },
      { protocol: "https", hostname: "cloudflare-ipfs.com"     },
      { protocol: "https", hostname: "assets.coingecko.com"    },
      { protocol: "https", hostname: "**.geckoterminal.com"    },
      { protocol: "https", hostname: "**.supabase.co"          },
    ],
  },

  // Required for ethers v6 in Next.js
  webpack: (config, { isServer }) => {
    if (!isServer) {
      config.resolve.fallback = {
        ...config.resolve.fallback,
        fs: false, net: false, tls: false,
      }
    }
    return config
  },

  // Pass contract addresses as build-time env (override with .env.local)
  env: {
    NEXT_PUBLIC_ASLE_CORE:   process.env.NEXT_PUBLIC_ASLE_CORE   || "",
    NEXT_PUBLIC_ASLE_VIEWS:  process.env.NEXT_PUBLIC_ASLE_VIEWS  || "",
    NEXT_PUBLIC_ASLE_ORACLE: process.env.NEXT_PUBLIC_ASLE_ORACLE || "",
    NEXT_PUBLIC_ASLE_BRIDGE: process.env.NEXT_PUBLIC_ASLE_BRIDGE || "",
  },
}

export default config
