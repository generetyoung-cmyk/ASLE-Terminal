"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import {
  ASLE_ADDRESSES, ABI_CORE, ABI_VIEWS,
  BASE_RPC, POLL_ENGINE_MS, isEngineDeployed,
} from "@/lib/config"
import type { EngineState, PriceDecomposition, BuyQuote, SellQuote, WalletInfo } from "@/lib/types"
import { wadToFloat, bpsToFloat, ASLE_TOTAL_SUPPLY } from "@/lib/utils"
import { fetchEthUsd } from "@/lib/gecko-api"

// ── Ethers is dynamically imported to avoid SSR issues ───────────────────────
let ethersLib: typeof import("ethers") | null = null

async function getEthers() {
  if (!ethersLib) {
    try { ethersLib = await import("ethers") } catch { return null }
  }
  return ethersLib
}

// ── Types ─────────────────────────────────────────────────────────────────────
export interface ASLEEngineHook {
  engine:        EngineState | null
  decomp:        PriceDecomposition | null
  isDeployed:    boolean
  isLoading:     boolean
  ethUsd:        number
  refresh:       () => void
  // Trading (requires signer)
  quoteBuy:      (ethIn: string)  => Promise<BuyQuote | null>
  quoteSell:     (tokAmt: string) => Promise<SellQuote | null>
  executeBuy:    (ethIn: string, maxSlippage: number, signer: unknown) => Promise<string | null>
  executeSell:   (tokAmt: string, minSlippage: number, signer: unknown, emergExit?: boolean) => Promise<string | null>
  getWalletInfo: (address: string) => Promise<WalletInfo | null>
}

// ── Default empty state ───────────────────────────────────────────────────────
const EMPTY_ENGINE: EngineState = {
  isDeployed:   false,
  spotPrice:    0, twapFast: 0, twapSlow: 0, spotPriceUsd: 0,
  poolEth:      0, poolTok: 0, floorPrice: 0, accBuyback: 0,
  supply:       { total: ASLE_TOTAL_SUPPLY, burned: 0, circulating: 0, onBase: 0, bridged: 0 },
  fees:         { buyBps: 0, sellBps: 0, effectiveBuy: 0, effectiveSell: 0, recycleRatio: 0 },
  state:        { trading: false, paused: false, circuitBroken: false, limitsOn: true, lpLocked: true, lpUnlockAt: null, paramsFrozen: false, phase: 0 },
  ema:          { V: 0, D: 0, sigma: 0 },
  bridge:       { activeChains: 0 },
  lastUpdate:   0,
}

// ── Hook ──────────────────────────────────────────────────────────────────────
export function useASLEEngine(): ASLEEngineHook {
  const deployed     = isEngineDeployed()
  const [engine,   setEngine]   = useState<EngineState | null>(deployed ? null : EMPTY_ENGINE)
  const [decomp,   setDecomp]   = useState<PriceDecomposition | null>(null)
  const [isLoading,setLoading]  = useState(deployed)
  const [ethUsd,   setEthUsd]   = useState(3000)
  const providerRef = useRef<unknown>(null)

  // ── Read provider ─────────────────────────────────────────────────────────
  const getProvider = useCallback(async () => {
    if (providerRef.current) return providerRef.current
    const ethers = await getEthers()
    if (!ethers) return null
    providerRef.current = new ethers.JsonRpcProvider(BASE_RPC)
    return providerRef.current
  }, [])

  // ── Fetch dashboard ───────────────────────────────────────────────────────
  const fetchDashboard = useCallback(async () => {
    if (!deployed) { setEngine(EMPTY_ENGINE); setLoading(false); return }
    const ethers = await getEthers()
    const provider = await getProvider()
    if (!ethers || !provider) { setLoading(false); return }

    try {
      const views = new ethers.Contract(ASLE_ADDRESSES.VIEWS, ABI_VIEWS, provider as Parameters<typeof ethers.Contract>[2])
      const [d, ethPrice] = await Promise.all([
        views.dashboardView(),
        fetchEthUsd().catch(() => 3000),
      ])
      setEthUsd(ethPrice)

      const spotEth = wadToFloat(d.spotPrice)
      const newState: EngineState = {
        isDeployed:   true,
        spotPrice:    spotEth,
        twapFast:     wadToFloat(d.twapPrice),
        twapSlow:     wadToFloat(d.twapSlowPrice),
        spotPriceUsd: spotEth * ethPrice,
        poolEth:      wadToFloat(d.poolEth),
        poolTok:      wadToFloat(d.poolTok),
        floorPrice:   wadToFloat(d.floorPrice),
        accBuyback:   wadToFloat(d.accBuyback),
        supply: {
          total:       ASLE_TOTAL_SUPPLY,
          burned:      wadToFloat(d.totalBurned),
          circulating: wadToFloat(d.circulatingOnBase),
          onBase:      wadToFloat(d.circulatingOnBase),
          bridged:     wadToFloat(d.lockedInBridge),
        },
        fees: {
          buyBps:       Number(d.buyBps),
          sellBps:      Number(d.sellBps),
          effectiveBuy:  Number(d.effectiveBuyBps),
          effectiveSell: Number(d.effectiveSellBps),
          recycleRatio:  Number(d.recycleRatioBps),
        },
        state: {
          trading:      d.tradingActive,
          paused:       d.paused,
          circuitBroken:d.circuitBroken,
          limitsOn:     d.limitsOn,
          lpLocked:     d.lpLocked,
          lpUnlockAt:   d.lpUnlockTimestamp > 0n ? new Date(Number(d.lpUnlockTimestamp) * 1000) : null,
          paramsFrozen: d.paramsFrozen,
          phase:        Number(d.phase) as 0 | 1 | 2 | 3,
        },
        ema: {
          V:     wadToFloat(d.emaV),
          D:     wadToFloat(d.emaD),
          sigma: wadToFloat(d.sigmaAdaptive),
        },
        bridge: { activeChains: Number(d.activeRemoteChains) },
        lastUpdate: Date.now(),
      }
      setEngine(newState)

      // Also fetch price decomposition
      try {
        const pd = await views.priceDecomposition()
        setDecomp({
          P0:       wadToFloat(pd.P0),
          T1:       wadToFloat(pd.T1),
          T2:       wadToFloat(pd.T2),
          T3:       wadToFloat(pd.T3),
          composed: wadToFloat(pd.composed),
          params: {
            alpha: bpsToFloat(pd.alpha),
            beta:  bpsToFloat(pd.beta),
            gamma: bpsToFloat(pd.gamma),
          },
          ema: {
            V:     wadToFloat(pd.emaV),
            D:     wadToFloat(pd.emaD),
            sigma: wadToFloat(pd.sigmaAdaptive),
          },
          phase: Number(pd.phase) as 0 | 1 | 2 | 3,
        })
      } catch { /* decomp is optional */ }

    } catch (err) {
      console.error("[ASLE Engine] dashboardView failed:", err)
    } finally {
      setLoading(false)
    }
  }, [deployed, getProvider])

  // ── Auto-poll ─────────────────────────────────────────────────────────────
  useEffect(() => {
    fetchDashboard()
    if (!deployed) return
    const id = setInterval(fetchDashboard, POLL_ENGINE_MS)
    return () => clearInterval(id)
  }, [deployed, fetchDashboard])

  // ── ETH price (always needed) ─────────────────────────────────────────────
  useEffect(() => {
    if (deployed) return // already fetched in dashboardView
    fetchEthUsd().then(p => setEthUsd(p)).catch(() => {})
    const id = setInterval(() => {
      fetchEthUsd().then(p => setEthUsd(p)).catch(() => {})
    }, 30_000)
    return () => clearInterval(id)
  }, [deployed])

  // ── Quote buy ─────────────────────────────────────────────────────────────
  const quoteBuy = useCallback(async (ethIn: string): Promise<BuyQuote | null> => {
    if (!deployed) return null
    const ethers = await getEthers()
    const provider = await getProvider()
    if (!ethers || !provider) return null
    try {
      const views = new ethers.Contract(ASLE_ADDRESSES.VIEWS, ABI_VIEWS, provider as Parameters<typeof ethers.Contract>[2])
      const ethWei = ethers.parseEther(ethIn)
      const q = await views.simulateBuy(ethWei)
      return {
        tokensOut:       q.tokensOut,
        tokensOutFmt:    ethers.formatEther(q.tokensOut),
        price:           q.price,
        priceFmt:        wadToFloat(q.price).toFixed(8),
        feeBps:          Number(q.feeBps),
        feeTokens:       q.feeTokens,
        priceImpactBps:  Number(q.priceImpactBps),
        priceImpactPct:  (Number(q.priceImpactBps) / 100).toFixed(2) + "%",
        recycleTokens:   q.recycleTokens,
        burnTokens:      q.burnTokens,
        wouldHitCap:     q.wouldHitCap,
      }
    } catch { return null }
  }, [deployed, getProvider])

  // ── Quote sell ────────────────────────────────────────────────────────────
  const quoteSell = useCallback(async (tokAmt: string): Promise<SellQuote | null> => {
    if (!deployed) return null
    const ethers = await getEthers()
    const provider = await getProvider()
    if (!ethers || !provider) return null
    try {
      const views = new ethers.Contract(ASLE_ADDRESSES.VIEWS, ABI_VIEWS, provider as Parameters<typeof ethers.Contract>[2])
      const tokWei = ethers.parseEther(tokAmt)
      const q = await views.simulateSell(tokWei, ethers.ZeroAddress)
      return {
        ethOut:          q.ethOut,
        ethOutFmt:       ethers.formatEther(q.ethOut),
        price:           q.price,
        priceFmt:        wadToFloat(q.price).toFixed(8),
        feeBps:          Number(q.feeBps),
        priceImpactBps:  Number(q.priceImpactBps),
        priceImpactPct:  (Number(q.priceImpactBps) / 100).toFixed(2) + "%",
        wouldHitFloor:   q.wouldHitFloor,
        wouldHitCap:     q.wouldHitCap,
        emergencyFee:    q.emergencyFee,
      }
    } catch { return null }
  }, [deployed, getProvider])

  // ── Execute buy ───────────────────────────────────────────────────────────
  const executeBuy = useCallback(async (
    ethIn: string,
    maxSlippage: number,
    signer: unknown,
  ): Promise<string | null> => {
    if (!deployed || !signer) return null
    const ethers = await getEthers()
    if (!ethers) return null
    try {
      const q = await quoteBuy(ethIn)
      if (!q) return null
      const ethWei  = ethers.parseEther(ethIn)
      const maxPrice = q.price * BigInt(Math.floor((100 + maxSlippage) * 100)) / 10_000n
      const salt     = BigInt(Math.floor(Math.random() * 1_000_000))
      const contract = new ethers.Contract(
        ASLE_ADDRESSES.CORE, ABI_CORE,
        signer as Parameters<typeof ethers.Contract>[2],
      )
      const tx = await contract.buy(salt, maxPrice, false, { value: ethWei })
      const receipt = await tx.wait()
      return receipt.hash
    } catch (err) {
      console.error("[ASLE Engine] buy failed:", err)
      return null
    }
  }, [deployed, quoteBuy])

  // ── Execute sell ──────────────────────────────────────────────────────────
  const executeSell = useCallback(async (
    tokAmt: string,
    minSlippage: number,
    signer: unknown,
    emergExit = false,
  ): Promise<string | null> => {
    if (!deployed || !signer) return null
    const ethers = await getEthers()
    if (!ethers) return null
    try {
      const q = await quoteSell(tokAmt)
      if (!q) return null
      const tokWei = ethers.parseEther(tokAmt)
      const minEth = q.ethOut * BigInt(Math.floor((100 - minSlippage) * 100)) / 10_000n
      const salt   = BigInt(Math.floor(Math.random() * 1_000_000))
      const contract = new ethers.Contract(
        ASLE_ADDRESSES.CORE, ABI_CORE,
        signer as Parameters<typeof ethers.Contract>[2],
      )
      const tx = await contract.sell(tokWei, salt, minEth, false, emergExit)
      const receipt = await tx.wait()
      return receipt.hash
    } catch (err) {
      console.error("[ASLE Engine] sell failed:", err)
      return null
    }
  }, [deployed, quoteSell])

  // ── Wallet info ───────────────────────────────────────────────────────────
  const getWalletInfo = useCallback(async (address: string): Promise<WalletInfo | null> => {
    if (!deployed || !address) return null
    const ethers = await getEthers()
    const provider = await getProvider()
    if (!ethers || !provider) return null
    try {
      const views = new ethers.Contract(ASLE_ADDRESSES.VIEWS, ABI_VIEWS, provider as Parameters<typeof ethers.Contract>[2])
      const [w, ethBal] = await Promise.all([
        views.walletInfo(address),
        (provider as { getBalance: (a: string) => Promise<bigint> }).getBalance(address),
      ])
      return {
        address,
        balanceAsle:    w.balance,
        balanceEth:     ethBal,
        balanceAsleFmt: parseFloat(ethers.formatEther(w.balance)).toLocaleString("en-US", { maximumFractionDigits: 2 }),
        balanceEthFmt:  parseFloat(ethers.formatEther(ethBal)).toFixed(4),
        valueUsd:       parseFloat(ethers.formatEther(w.balanceUSD)),
        pctOfSupply:    (Number(w.pctOfSupply) / 100).toFixed(4) + "%",
        tier:           Number(w.holderTier) as 0 | 1 | 2 | 3,
        tierLabel:      ["Basic", "Silver", "Gold", "Platinum"][w.holderTier] || "Basic",
        feeExempt:      w.feeExempt,
        limitExempt:    w.limitExempt,
        sellFeePct:     (Number(w.sellFeeEstimate) / 100).toFixed(2) + "%",
        maxCanBuy:      w.maxCanBuy,
        maxCanSell:     w.maxCanSell,
      }
    } catch { return null }
  }, [deployed, getProvider])

  return {
    engine,
    decomp,
    isDeployed: deployed,
    isLoading,
    ethUsd,
    refresh:    fetchDashboard,
    quoteBuy,
    quoteSell,
    executeBuy,
    executeSell,
    getWalletInfo,
  }
}
