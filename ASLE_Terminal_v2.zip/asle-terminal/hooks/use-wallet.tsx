"use client"

import { useState, useEffect, useCallback } from "react"
import { BASE_CHAIN_ID, BASE_RPC } from "@/lib/config"
import { fmtAddr } from "@/lib/utils"

export interface WalletState {
  address:      string | null
  shortAddress: string
  isConnected:  boolean
  chainId:      number | null
  isCorrectChain: boolean
  signer:       unknown
  provider:     unknown
}

export interface WalletHook extends WalletState {
  connect:     () => Promise<void>
  disconnect:  () => void
  switchChain: () => Promise<void>
  isConnecting:boolean
  error:       string | null
}

const BASE_CHAIN_HEX = "0x" + BASE_CHAIN_ID.toString(16)

const BASE_CHAIN_PARAMS = {
  chainId:           BASE_CHAIN_HEX,
  chainName:         "Base",
  nativeCurrency:    { name: "Ether", symbol: "ETH", decimals: 18 },
  rpcUrls:           [BASE_RPC],
  blockExplorerUrls: ["https://basescan.org"],
}

export function useWallet(): WalletHook {
  const [state,        setState]       = useState<WalletState>({
    address:      null,
    shortAddress: "",
    isConnected:  false,
    chainId:      null,
    isCorrectChain: false,
    signer:       null,
    provider:     null,
  })
  const [isConnecting, setConnecting]  = useState(false)
  const [error,        setError]       = useState<string | null>(null)

  // ── Internal: build state from provider ─────────────────────────────────
  const refreshState = useCallback(async (provider: unknown) => {
    if (!provider) return
    try {
      const ethers = await import("ethers")
      const bp     = new ethers.BrowserProvider(provider as Parameters<typeof ethers.BrowserProvider>[0])
      const [accounts, network] = await Promise.all([
        bp.listAccounts(),
        bp.getNetwork(),
      ])
      const acct = accounts[0]
      if (!acct) { setState(s => ({ ...s, isConnected: false, address: null, signer: null })); return }
      const address  = await acct.getAddress()
      const chainId  = Number(network.chainId)
      const signer   = await bp.getSigner()
      setState({
        address,
        shortAddress:  fmtAddr(address),
        isConnected:   true,
        chainId,
        isCorrectChain: chainId === BASE_CHAIN_ID,
        signer,
        provider,
      })
    } catch (err) {
      console.error("[Wallet] refresh error:", err)
    }
  }, [])

  // ── Check existing connection on mount ──────────────────────────────────
  useEffect(() => {
    const win = window as unknown as { ethereum?: Record<string, unknown> }
    if (!win.ethereum) return
    const eth = win.ethereum
    // Silently check if already connected (no prompt)
    const ethProvider = eth
    ;(ethProvider as { request: (a: { method: string }) => Promise<string[]> })
      .request({ method: "eth_accounts" })
      .then(accounts => {
        if (accounts.length > 0) refreshState(eth)
      })
      .catch(() => {})

    // Event listeners
    const onAccounts = (accounts: string[]) => {
      if (accounts.length === 0) {
        setState(s => ({ ...s, isConnected: false, address: null, signer: null, provider: null }))
      } else {
        refreshState(eth)
      }
    }
    const onChainChanged = () => refreshState(eth)

    ;(eth as { on: (e: string, fn: unknown) => void }).on("accountsChanged", onAccounts)
    ;(eth as { on: (e: string, fn: unknown) => void }).on("chainChanged", onChainChanged)

    return () => {
      ;(eth as { removeListener: (e: string, fn: unknown) => void }).removeListener("accountsChanged", onAccounts)
      ;(eth as { removeListener: (e: string, fn: unknown) => void }).removeListener("chainChanged", onChainChanged)
    }
  }, [refreshState])

  // ── Connect ───────────────────────────────────────────────────────────────
  const connect = useCallback(async () => {
    const win = window as unknown as { ethereum?: Record<string, unknown> }
    if (!win.ethereum) {
      setError("No wallet detected. Please install MetaMask.")
      return
    }
    setConnecting(true)
    setError(null)
    try {
      const eth = win.ethereum
      await (eth as { request: (a: { method: string }) => Promise<void> }).request({ method: "eth_requestAccounts" })
      await refreshState(eth)
      // Auto-switch to Base
      const chainId = await (eth as { request: (a: { method: string }) => Promise<string> }).request({ method: "eth_chainId" })
      if (parseInt(chainId, 16) !== BASE_CHAIN_ID) {
        await switchChainInternal(eth)
      }
    } catch (err: unknown) {
      const e = err as { code?: number; message?: string }
      if (e?.code === 4001) setError("Connection rejected.")
      else setError(e?.message || "Connection failed.")
    } finally {
      setConnecting(false)
    }
  }, [refreshState])

  // ── Disconnect (local state only — MetaMask doesn't have a disconnect API) ─
  const disconnect = useCallback(() => {
    setState({
      address:      null,
      shortAddress: "",
      isConnected:  false,
      chainId:      null,
      isCorrectChain: false,
      signer:       null,
      provider:     null,
    })
  }, [])

  // ── Switch to Base ────────────────────────────────────────────────────────
  async function switchChainInternal(eth: unknown) {
    try {
      await (eth as { request: (a: { method: string; params: unknown[] }) => Promise<void> }).request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: BASE_CHAIN_HEX }],
      })
    } catch (switchErr: unknown) {
      const e = switchErr as { code?: number }
      // Chain not added yet
      if (e?.code === 4902) {
        await (eth as { request: (a: { method: string; params: unknown[] }) => Promise<void> }).request({
          method: "wallet_addEthereumChain",
          params: [BASE_CHAIN_PARAMS],
        })
      }
    }
  }

  const switchChain = useCallback(async () => {
    const win = window as unknown as { ethereum?: unknown }
    if (!win.ethereum) return
    setError(null)
    try {
      await switchChainInternal(win.ethereum)
      await refreshState(win.ethereum)
    } catch (err: unknown) {
      const e = err as { message?: string }
      setError(e?.message || "Failed to switch network.")
    }
  }, [refreshState])

  return { ...state, connect, disconnect, switchChain, isConnecting, error }
}
