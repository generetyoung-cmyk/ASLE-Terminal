"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { fetchOHLCV, fetchTokenPools, type OHLCVTimeframe } from "@/lib/gecko-api"
import { POLL_TRADES_MS } from "@/lib/config"
import { calcCurveProgress } from "@/lib/utils"
import type { CandleData, CurveDepth, DepthLevel, TradeEvent, LaunchedToken } from "@/lib/types"

// ── Simulate bonding curve depth from pool state ──────────────────────────────
// Uses AMM invariant: k = poolEth * poolTok
// Generates ask levels (cost ETH to buy more tokens) and
// bid levels (ETH received by selling tokens into pool).
function buildCurveDepth(poolEth: number, poolTok: number, midPrice: number): CurveDepth {
  if (poolEth <= 0 || poolTok <= 0 || midPrice <= 0) {
    return { asks: [], bids: [], spread: 0, spreadPct: 0, midPrice }
  }

  const k = poolEth * poolTok
  const STEPS = 20

  const asks: DepthLevel[] = []
  let cumulativeEth = 0
  for (let i = 1; i <= STEPS; i++) {
    // Buy i% of remaining pool tokens
    const buyFraction = 0.005 * i  // 0.5% increments
    const tokToBuy    = poolTok * buyFraction
    const newPoolTok  = poolTok - tokToBuy
    const newPoolEth  = k / newPoolTok
    const ethCost     = newPoolEth - poolEth
    const marginalPrice = ethCost / tokToBuy
    cumulativeEth += ethCost
    asks.push({
      price:    marginalPrice,
      sizeEth:  ethCost,
      sizeTok:  tokToBuy,
      total:    cumulativeEth,
      pct:      0,
    })
  }

  const bids: DepthLevel[] = []
  let cumulativeTok = 0
  for (let i = 1; i <= STEPS; i++) {
    // Sell i * 0.5% of pool tokens back in
    const sellFraction = 0.005 * i
    const tokToSell   = poolTok * sellFraction
    const newPoolTok  = poolTok + tokToSell
    const newPoolEth  = k / newPoolTok
    const ethReceived = poolEth - newPoolEth
    const marginalPrice = ethReceived / tokToSell
    cumulativeTok += tokToSell
    bids.push({
      price:    marginalPrice,
      sizeEth:  ethReceived,
      sizeTok:  tokToSell,
      total:    cumulativeTok,
      pct:      0,
    })
  }

  // Normalize depth bars
  const maxAsk = asks[asks.length - 1]?.total || 1
  const maxBid = bids[bids.length - 1]?.total || 1
  asks.forEach(a => { a.pct = (a.total / maxAsk) * 100 })
  bids.forEach(b => { b.pct = (b.total / maxBid) * 100 })

  const bestAsk = asks[0]?.price || midPrice * 1.001
  const bestBid = bids[0]?.price || midPrice * 0.999
  const spread  = bestAsk - bestBid
  const spreadPct = midPrice > 0 ? (spread / midPrice) * 100 : 0

  return { asks, bids, spread, spreadPct, midPrice }
}

// ── Hook ──────────────────────────────────────────────────────────────────────
export type ChartTimeframe = "1m" | "5m" | "15m" | "1h" | "4h" | "1d"

const TF_MAP: Record<ChartTimeframe, { timeframe: OHLCVTimeframe; aggregate: number }> = {
  "1m":  { timeframe: "minute", aggregate: 1  },
  "5m":  { timeframe: "minute", aggregate: 5  },
  "15m": { timeframe: "minute", aggregate: 15 },
  "1h":  { timeframe: "hour",   aggregate: 1  },
  "4h":  { timeframe: "hour",   aggregate: 4  },
  "1d":  { timeframe: "day",    aggregate: 1  },
}

export interface SelectedTokenHook {
  candles:       CandleData[]
  trades:        TradeEvent[]
  depth:         CurveDepth | null
  poolAddress:   string
  timeframe:     ChartTimeframe
  setTimeframe:  (tf: ChartTimeframe) => void
  isLoading:     boolean
  curveProgress: number
}

export function useSelectedToken(
  token: LaunchedToken | null,
  enginePoolEth: number,
  enginePoolTok: number,
): SelectedTokenHook {
  const [candles,      setCandles]     = useState<CandleData[]>([])
  const [trades,       setTrades]      = useState<TradeEvent[]>([])
  const [depth,        setDepth]       = useState<CurveDepth | null>(null)
  const [poolAddress,  setPoolAddress] = useState("")
  const [timeframe,    setTimeframe]   = useState<ChartTimeframe>("1h")
  const [isLoading,    setLoading]     = useState(false)
  const [curveProgress,setProgress]   = useState(0)
  const lastTokenRef   = useRef<string | null>(null)

  // ── Resolve pool address & fetch chart ──────────────────────────────────
  const fetchChart = useCallback(async () => {
    if (!token?.contractAddress) { setCandles([]); return }

    const isNewToken = lastTokenRef.current !== token.contractAddress
    if (isNewToken) {
      setLoading(true)
      setCandles([])
      lastTokenRef.current = token.contractAddress
    }

    try {
      // Get pool address
      let pool = token.topPoolAddress
      if (!pool) {
        const pools = await fetchTokenPools(token.contractAddress)
        pool = pools[0]?.address || ""
      }
      if (pool) setPoolAddress(pool)

      if (!pool) { setLoading(false); return }

      const { timeframe: tf, aggregate } = TF_MAP[timeframe]
      const data = await fetchOHLCV(pool, tf, aggregate, 300)
      setCandles(data)
    } catch (err) {
      console.error("[SelectedToken] chart error:", err)
    } finally {
      setLoading(false)
    }
  }, [token, timeframe])

  useEffect(() => { fetchChart() }, [fetchChart])

  // ── Depth from engine pool state (or simulated) ──────────────────────────
  useEffect(() => {
    const poolEth = enginePoolEth || token?.poolEth || 0
    const poolTok = enginePoolTok || token?.poolTok || 0
    const mid     = token?.priceEth || 0

    if (poolEth > 0 && poolTok > 0) {
      setDepth(buildCurveDepth(poolEth, poolTok, mid))
      setProgress(calcCurveProgress(poolEth))
    } else if (token) {
      setDepth(null)
      setProgress(token.curveProgress)
    }
  }, [enginePoolEth, enginePoolTok, token])

  // ── Simulated recent trades (from GeckoTerminal trades endpoint if available) ──
  // GT doesn't have a free trades endpoint, so we derive from OHLCV ticks
  useEffect(() => {
    if (candles.length < 2) return
    const recent = candles.slice(-40).flatMap((c, i) => {
      if (i === 0) return []
      const prev = candles[candles.length - 40 + i - 1]
      const isBuy = c.close >= prev.close
      return [{
        id:        `${c.time}-${i}`,
        txHash:    "",
        wallet:    "",
        side:      isBuy ? "buy" as const : "sell" as const,
        ethAmt:    c.volume / (c.close || 1) / 3000,
        tokAmt:    c.volume / (c.close || 1),
        price:     c.close,
        priceUsd:  c.close,
        feeBps:    0,
        timestamp: c.time,
        blockNum:  0,
      }]
    }).reverse()
    setTrades(recent)
  }, [candles])

  // ── Poll trades ──────────────────────────────────────────────────────────
  useEffect(() => {
    const id = setInterval(fetchChart, POLL_TRADES_MS)
    return () => clearInterval(id)
  }, [fetchChart])

  return {
    candles, trades, depth, poolAddress,
    timeframe, setTimeframe,
    isLoading, curveProgress,
  }
}
