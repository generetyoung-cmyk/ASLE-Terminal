"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { SUPABASE_URL, SUPABASE_ANON, POLL_TOKENLIST_MS } from "@/lib/config"
import { fetchTrendingPools, fetchNewTokens, fetchTokenInfo, fetchEthUsd } from "@/lib/gecko-api"
import { calcCurveProgress } from "@/lib/utils"
import type { LaunchedToken, SBCommunity, TokenFilter, TokenSortKey } from "@/lib/types"

// ── Supabase fetch helper ─────────────────────────────────────────────────────
async function sbFetch<T>(path: string): Promise<T[]> {
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1${path}`, {
      headers: {
        apikey:        SUPABASE_ANON,
        Authorization: `Bearer ${SUPABASE_ANON}`,
        Accept:        "application/json",
      },
      signal: AbortSignal.timeout(8_000),
    })
    if (!res.ok) return []
    return await res.json() as T[]
  } catch { return [] }
}

// ── Token normalization ───────────────────────────────────────────────────────
function normalizeCommunityToken(
  comm: SBCommunity,
  gtInfo: Awaited<ReturnType<typeof fetchTokenInfo>>,
  ethUsd: number,
): LaunchedToken {
  const createdAt = comm.created_at ? new Date(comm.created_at).getTime() : 0
  const isNew     = Date.now() - createdAt < 24 * 3600 * 1000

  return {
    contractAddress: comm.contract_address || "",
    name:            gtInfo?.name       || comm.name || "Unknown",
    symbol:          gtInfo?.symbol     || comm.name?.split(" ")[0]?.toUpperCase() || "?",
    logoUrl:         comm.logo_url      || gtInfo?.imageUrl || "",
    bannerUrl:       comm.banner_url    || "",
    description:     comm.desc         || "",

    priceUsd:        gtInfo?.priceUsd       || 0,
    priceEth:        (gtInfo?.priceUsd || 0) / ethUsd,
    priceChangeH1:   gtInfo?.priceChange1h  || 0,
    priceChangeH6:   gtInfo?.priceChange6h  || 0,
    priceChange24h:  gtInfo?.priceChange24h || 0,
    volume24h:       gtInfo?.volume24h      || 0,
    volumeH1:        0,
    marketCap:       gtInfo?.marketCap      || 0,
    fdv:             gtInfo?.fdv            || 0,
    liquidity:       gtInfo?.liquidity      || 0,
    txns24h:         0,
    buys24h:         0,
    sells24h:        0,
    holdersCount:    0,

    poolEth:         0,
    poolTok:         0,
    curveProgress:   0,
    phase:           0,

    communityId:     comm.id,
    memberCount:     comm.members || 0,
    ownerWallet:     comm.owner_wallet || "",

    createdAt,
    isASLE:          false,
    isNew,
    isTrending:      (gtInfo?.volume24h || 0) > 50_000,
    isGraduating:    false,
    topPoolAddress:  gtInfo?.topPoolAddress || "",
  }
}

function normalizeGTToken(
  gt: { address: string; name: string; symbol: string; priceUsd: number; priceChange24h: number; volume24h: number; fdv: number; marketCap: number; imageUrl: string; liquidity: number; topPoolAddress: string },
  ethUsd: number,
  existingAddresses: Set<string>,
): LaunchedToken | null {
  if (!gt.address || existingAddresses.has(gt.address.toLowerCase())) return null
  return {
    contractAddress: gt.address,
    name:            gt.name,
    symbol:          gt.symbol,
    logoUrl:         gt.imageUrl,
    bannerUrl:       "",
    description:     "",

    priceUsd:        gt.priceUsd,
    priceEth:        gt.priceUsd / ethUsd,
    priceChangeH1:   0,
    priceChangeH6:   0,
    priceChange24h:  gt.priceChange24h,
    volume24h:       gt.volume24h,
    volumeH1:        0,
    marketCap:       gt.marketCap || gt.fdv,
    fdv:             gt.fdv,
    liquidity:       gt.liquidity,
    txns24h:         0,
    buys24h:         0,
    sells24h:        0,
    holdersCount:    0,

    poolEth:         0,
    poolTok:         0,
    curveProgress:   calcCurveProgress(0),
    phase:           0,

    communityId:     null,
    memberCount:     0,
    ownerWallet:     "",

    createdAt:       0,
    isASLE:          false,
    isNew:           false,
    isTrending:      gt.volume24h > 50_000,
    isGraduating:    false,
    topPoolAddress:  gt.topPoolAddress,
  }
}

// ── Hook ──────────────────────────────────────────────────────────────────────
export interface TokenListHook {
  tokens:          LaunchedToken[]
  isLoading:       boolean
  ethUsd:          number
  filter:          TokenFilter
  sortKey:         TokenSortKey
  search:          string
  setFilter:       (f: TokenFilter) => void
  setSortKey:      (k: TokenSortKey) => void
  setSearch:       (s: string) => void
  selectedToken:   LaunchedToken | null
  setSelectedToken:(t: LaunchedToken | null) => void
  refresh:         () => void
}

export function useTokenList(): TokenListHook {
  const [allTokens,     setAllTokens]     = useState<LaunchedToken[]>([])
  const [isLoading,     setLoading]       = useState(true)
  const [ethUsd,        setEthUsd]        = useState(3000)
  const [filter,        setFilter]        = useState<TokenFilter>("all")
  const [sortKey,       setSortKey]       = useState<TokenSortKey>("volume")
  const [search,        setSearch]        = useState("")
  const [selectedToken, setSelectedToken] = useState<LaunchedToken | null>(null)
  const loadedRef = useRef(false)

  // ── Load tokens ─────────────────────────────────────────────────────────
  const load = useCallback(async () => {
    if (loadedRef.current) setLoading(false) // subsequent loads: silent
    else setLoading(true)

    try {
      const ethPrice = await fetchEthUsd().catch(() => 3000)
      setEthUsd(ethPrice)

      // 1. ASLE dApp launched tokens — from Supabase communities (type=project)
      const communities = await sbFetch<SBCommunity>(
        `/communities?select=*&type=eq.project&order=created_at.desc&limit=100`
      )

      // Fetch GT info for each community token in parallel (batched)
      const communityTokens: LaunchedToken[] = []
      const communityAddresses = new Set<string>()

      if (communities.length > 0) {
        const gtInfos = await Promise.allSettled(
          communities
            .filter(c => c.contract_address && c.contract_address !== "0x0000000000000000000000000000000000000000")
            .map(c => fetchTokenInfo(c.contract_address))
        )

        communities
          .filter(c => c.contract_address && c.contract_address !== "0x0000000000000000000000000000000000000000")
          .forEach((comm, i) => {
            const gtResult = gtInfos[i]
            const gt = gtResult?.status === "fulfilled" ? gtResult.value : null
            const tok = normalizeCommunityToken(comm, gt, ethPrice)
            communityTokens.push(tok)
            communityAddresses.add(comm.contract_address.toLowerCase())
          })

        // Also add communities without deployed addresses (pre-launch tokens)
        communities
          .filter(c => !c.contract_address || c.contract_address === "0x0000000000000000000000000000000000000000")
          .forEach(comm => {
            communityTokens.push(normalizeCommunityToken(comm, null, ethPrice))
          })
      }

      // 2. Supplement with GeckoTerminal trending + new tokens on Base
      const [trending, newTokens] = await Promise.all([
        fetchTrendingPools(1).catch(() => []),
        fetchNewTokens(1).catch(() => []),
      ])

      const gtTokens: LaunchedToken[] = []
      const allGT = [...trending, ...newTokens]
      const seenGT = new Set<string>()

      for (const gt of allGT) {
        if (!gt.address || seenGT.has(gt.address.toLowerCase())) continue
        seenGT.add(gt.address.toLowerCase())
        const tok = normalizeGTToken(gt, ethPrice, communityAddresses)
        if (tok) gtTokens.push(tok)
      }

      setAllTokens([...communityTokens, ...gtTokens])

      // Auto-select first token if none selected
      if (!loadedRef.current && communityTokens.length + gtTokens.length > 0) {
        setSelectedToken(prev => prev || communityTokens[0] || gtTokens[0])
      }

      loadedRef.current = true
    } catch (err) {
      console.error("[TokenList] load error:", err)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
    const id = setInterval(load, POLL_TOKENLIST_MS)
    return () => clearInterval(id)
  }, [load])

  // ── Filtered & sorted view ───────────────────────────────────────────────
  const tokens: LaunchedToken[] = allTokens
    .filter(t => {
      if (search) {
        const q = search.toLowerCase()
        if (!t.name.toLowerCase().includes(q) &&
            !t.symbol.toLowerCase().includes(q) &&
            !t.contractAddress.toLowerCase().includes(q)) return false
      }
      if (filter === "new")        return t.isNew
      if (filter === "trending")   return t.isTrending
      if (filter === "graduating") return t.curveProgress >= 70
      return true
    })
    .sort((a, b) => {
      switch (sortKey) {
        case "volume":        return b.volume24h - a.volume24h
        case "marketCap":     return b.marketCap  - a.marketCap
        case "priceChange":   return b.priceChange24h - a.priceChange24h
        case "liquidity":     return b.liquidity  - a.liquidity
        case "curveProgress": return b.curveProgress - a.curveProgress
        case "age":           return b.createdAt - a.createdAt
        default:              return b.volume24h - a.volume24h
      }
    })

  return {
    tokens, isLoading, ethUsd,
    filter, sortKey, search,
    setFilter, setSortKey, setSearch,
    selectedToken, setSelectedToken,
    refresh: load,
  }
}
