// ─────────────────────────────────────────────────────────────────────────────
// ASLE Terminal — Central Configuration
// Wire contract addresses here after deployment. All other modules read from
// this file so a single update propagates everywhere.
// ─────────────────────────────────────────────────────────────────────────────

export const ZERO_ADDR = "0x0000000000000000000000000000000000000000"

// ── ASLE Engine Contract Addresses (Base Mainnet) ──────────────────────────
// TODO: Replace with deployed addresses post-launch.
// Set in `.env.local`:
//   NEXT_PUBLIC_ASLE_CORE=0x...
//   NEXT_PUBLIC_ASLE_VIEWS=0x...
//   NEXT_PUBLIC_ASLE_ORACLE=0x...
//   NEXT_PUBLIC_ASLE_BRIDGE=0x...
export const ASLE_ADDRESSES = {
  CORE:   process.env.NEXT_PUBLIC_ASLE_CORE   || ZERO_ADDR,
  VIEWS:  process.env.NEXT_PUBLIC_ASLE_VIEWS  || ZERO_ADDR,
  ORACLE: process.env.NEXT_PUBLIC_ASLE_ORACLE || ZERO_ADDR,
  BRIDGE: process.env.NEXT_PUBLIC_ASLE_BRIDGE || ZERO_ADDR,
} as const

export function isEngineDeployed(): boolean {
  return (
    ASLE_ADDRESSES.CORE   !== ZERO_ADDR &&
    ASLE_ADDRESSES.VIEWS  !== ZERO_ADDR &&
    ASLE_ADDRESSES.ORACLE !== ZERO_ADDR
  )
}

// ── ASLE Token Constants ────────────────────────────────────────────────────
export const ASLE_TOTAL_SUPPLY    = 33_000_000  // fixed cap
export const ASLE_ALLOC_POOL      = 16_500_000  // initial pool tokens
export const ASLE_ALLOC_TREASURY  =  6_600_000
export const ASLE_ALLOC_TEAM      =  4_950_000
export const ASLE_ALLOC_SALE      =  3_300_000
export const ASLE_ALLOC_AIRDROP   =  1_650_000

// ── Network ────────────────────────────────────────────────────────────────
export const BASE_CHAIN_ID    = 8453
export const BASE_RPC         = "https://mainnet.base.org"
export const BASE_EXPLORER    = "https://basescan.org"

// ── ASLE dApp Supabase (shared with dApp — read access only from terminal) ─
// The dApp already uses these for communities, profiles, DMs.
// Terminal reads `communities` table (type='project') to get launched tokens.
export const SUPABASE_URL  = "https://apyvfvydtdwgqppqmgdc.supabase.co"
export const SUPABASE_ANON = "sb_secret_ixgDjQJxCdZJNT2l7Won8Q_-6EuUORi"

// ── GeckoTerminal API ──────────────────────────────────────────────────────
// Free tier, no auth. Rate limit: ~30 req/min.
export const GT_BASE_URL    = "https://api.geckoterminal.com/api/v2"
export const GT_NETWORK     = "base"

// ── Polling Intervals (ms) ─────────────────────────────────────────────────
export const POLL_ENGINE_MS    = 12_000  // 1 Base block ≈ 2s, poll every 6 blocks
export const POLL_PRICE_MS     = 15_000
export const POLL_TRADES_MS    = 10_000
export const POLL_TOKENLIST_MS = 60_000  // token list refreshes less aggressively

// ── ABIs (minimal, for ethers.js reads) ────────────────────────────────────
export const ABI_CORE = [
  "function viewPrice() view returns (uint256)",
  "function poolEth() view returns (uint128)",
  "function poolTok() view returns (uint128)",
  "function circuitBroken() view returns (bool)",
  "function tradingActive() view returns (bool)",
  "function paused() view returns (bool)",
  "function twap() view returns (uint256)",
  "function totalBurned() view returns (uint256)",
  "function totalSupply() view returns (uint256)",
  "function balanceOf(address) view returns (uint256)",
  "function buyBps() view returns (uint256)",
  "function sellBps() view returns (uint256)",
  "function currentDynamicParams() view returns (uint256 alpha_, uint256 beta_, uint256 gamma_, uint8 phase)",
  "event Buy(address indexed who, uint256 ethIn, uint256 tokOut, uint256 price, uint256 feeBps)",
  "event Sell_(address indexed who, uint256 tokIn, uint256 ethOut, uint256 price, uint256 feeBps)",
  "function buy(uint256 salt, uint256 maxPrice, bool useCommit) payable",
  "function sell(uint256 tokAmt, uint256 salt, uint256 minEth, bool useCommit, bool emergExit)",
] as const

export const ABI_VIEWS = [
  "function dashboardView() view returns (tuple(uint256 spotPrice,uint256 twapPrice,uint256 twapSlowPrice,bool circuitBroken,uint128 poolEth,uint128 poolTok,uint256 floorPrice,uint256 accBuyback,uint256 totalSupply,uint256 totalBurned,uint256 circulatingOnBase,uint256 lockedInBridge,uint256 buyBps,uint256 sellBps,uint256 effectiveBuyBps,uint256 effectiveSellBps,uint256 recycleRatioBps,bool tradingActive,bool limitsOn,bool paused,bool lpLocked,uint256 lpUnlockTimestamp,bool paramsFrozen,uint8 phase,uint128 emaV,uint128 emaD,uint256 sigmaAdaptive,uint256 activeRemoteChains))",
  "function simulateBuy(uint256 ethIn) view returns (tuple(uint256 tokensOut,uint256 price,uint256 feeBps,uint256 feeTokens,uint256 priceImpactBps,uint256 recycleTokens,uint256 burnTokens,uint256 treasuryTokens,bool wouldHitCap))",
  "function simulateSell(uint256 tokAmt, address seller) view returns (tuple(uint256 ethOut,uint256 price,uint256 feeBps,uint256 feeTokens,uint256 priceImpactBps,bool wouldHitFloor,bool wouldHitCap,uint256 emergencyFee))",
  "function walletInfo(address) view returns (tuple(uint256 balance,uint256 balanceUSD,uint256 pctOfSupply,uint8 holderTier,bool feeExempt,bool limitExempt,uint256 sellFeeEstimate,uint256 maxCanBuy,uint256 maxCanSell))",
  "function priceDecomposition() view returns (tuple(uint256 P0,uint256 T1,uint256 T2,uint256 T3,uint256 composed,uint256 alpha,uint256 beta,uint256 gamma,uint8 phase,uint256 emaV,uint256 emaD,uint256 sigmaAdaptive))",
  "function supplyBreakdown() view returns (uint256,uint256,uint256,uint256,uint256,uint256,bool)",
] as const
