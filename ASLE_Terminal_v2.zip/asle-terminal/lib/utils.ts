import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// ── Price Formatting ──────────────────────────────────────────────────────────
export function fmtPrice(price: number, opts?: { forceDecimals?: number }): string {
  if (price === 0 || !isFinite(price)) return "—"
  if (opts?.forceDecimals !== undefined)
    return price.toLocaleString("en-US", {
      minimumFractionDigits: opts.forceDecimals,
      maximumFractionDigits: opts.forceDecimals,
    })
  if (price >= 100_000) return price.toLocaleString("en-US", { maximumFractionDigits: 0 })
  if (price >= 1_000)   return price.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  if (price >= 1)       return price.toFixed(4)
  if (price >= 0.001)   return price.toFixed(6)
  if (price >= 0.000001) return price.toFixed(8)
  // Very small: scientific notation
  return price.toExponential(4)
}

export function fmtPriceUsd(price: number): string {
  if (price === 0 || !isFinite(price)) return "—"
  if (price >= 1_000_000) return `$${(price / 1_000_000).toFixed(2)}M`
  if (price >= 1_000)     return `$${price.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
  if (price >= 1)         return `$${price.toFixed(4)}`
  if (price >= 0.001)     return `$${price.toFixed(6)}`
  return `$${price.toExponential(4)}`
}

// ── Volume / Market Cap ───────────────────────────────────────────────────────
export function fmtCompact(n: number, prefix = "$"): string {
  if (!isFinite(n) || n === 0) return "—"
  if (n >= 1_000_000_000) return `${prefix}${(n / 1_000_000_000).toFixed(2)}B`
  if (n >= 1_000_000)     return `${prefix}${(n / 1_000_000).toFixed(2)}M`
  if (n >= 1_000)         return `${prefix}${(n / 1_000).toFixed(1)}K`
  return `${prefix}${n.toFixed(2)}`
}

export function fmtCompactNoPrefix(n: number): string {
  return fmtCompact(n, "")
}

// ── Percentage ────────────────────────────────────────────────────────────────
export function fmtPct(pct: number, decimals = 2): string {
  if (!isFinite(pct)) return "—"
  const sign = pct >= 0 ? "+" : ""
  return `${sign}${pct.toFixed(decimals)}%`
}

export function fmtPctAbs(pct: number, decimals = 2): string {
  if (!isFinite(pct)) return "—"
  return `${Math.abs(pct).toFixed(decimals)}%`
}

// ── ETH amounts ───────────────────────────────────────────────────────────────
export function fmtEth(eth: number, decimals = 4): string {
  if (!isFinite(eth) || eth === 0) return "0 ETH"
  if (eth < 0.00001) return `${eth.toExponential(3)} ETH`
  return `${eth.toFixed(decimals)} ETH`
}

// ── Token amounts ─────────────────────────────────────────────────────────────
export function fmtTokens(n: number): string {
  if (!isFinite(n)) return "—"
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(2)}M`
  if (n >= 1_000)     return `${(n / 1_000).toFixed(1)}K`
  return n.toLocaleString("en-US", { maximumFractionDigits: 2 })
}

// ── Time ──────────────────────────────────────────────────────────────────────
export function fmtTime(ts: number): string {
  const d = new Date(ts)
  return `${d.getHours().toString().padStart(2, "0")}:${d.getMinutes().toString().padStart(2, "0")}:${d.getSeconds().toString().padStart(2, "0")}`
}

export function fmtTimeAgo(ts: number): string {
  const diff = Date.now() - ts
  const s = Math.floor(diff / 1000)
  if (s < 60)          return `${s}s ago`
  if (s < 3600)        return `${Math.floor(s / 60)}m ago`
  if (s < 86400)       return `${Math.floor(s / 3600)}h ago`
  return `${Math.floor(s / 86400)}d ago`
}

export function fmtCountdown(seconds: number): string {
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = seconds % 60
  return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`
}

// ── Address ───────────────────────────────────────────────────────────────────
export function fmtAddr(addr: string, chars = 4): string {
  if (!addr || addr.length < 10) return addr || "—"
  return `${addr.slice(0, chars + 2)}…${addr.slice(-chars)}`
}

// ── BigInt / WAD conversion ───────────────────────────────────────────────────
const WAD = 10n ** 18n

export function wadToFloat(wad: bigint): number {
  return Number(wad * 10000n / WAD) / 10000
}

export function floatToWad(n: number): bigint {
  return BigInt(Math.round(n * 1e18))
}

// ── BPS ───────────────────────────────────────────────────────────────────────
export function bpsToFloat(bps: bigint | number): number {
  return Number(bps) / 10000
}

export function bpsToPercent(bps: bigint | number): string {
  return (Number(bps) / 100).toFixed(2) + "%"
}

// ── Token logo URL ────────────────────────────────────────────────────────────
export function tokenLogoUrl(addr: string, logoUrl?: string): string {
  if (logoUrl && logoUrl.startsWith("data:")) return logoUrl
  if (logoUrl && logoUrl.startsWith("http"))  return logoUrl
  if (logoUrl && logoUrl.startsWith("ipfs://")) {
    return "https://cloudflare-ipfs.com/ipfs/" + logoUrl.slice(7)
  }
  // GeckoTerminal fallback
  return `https://assets.coingecko.com/coins/images/large.png`
}

// ── Phase color ───────────────────────────────────────────────────────────────
export function phaseColor(phase: 0 | 1 | 2 | 3): string {
  return ["#4A5568", "#3B82F6", "#00D4AA", "#C4A35A"][phase]
}

// ── Curve progress ────────────────────────────────────────────────────────────
// Graduation threshold: when poolEth reaches target (configurable per protocol)
// For ASLE: roughly when bonding curve generates enough ETH to provide DEX liquidity.
// Using 30 ETH as a soft milestone (not hard-coded in contract — just terminal display).
export const GRADUATION_TARGET_ETH = 30

export function calcCurveProgress(poolEth: number): number {
  return Math.min(100, (poolEth / GRADUATION_TARGET_ETH) * 100)
}

// ── Clipboard ─────────────────────────────────────────────────────────────────
export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text)
    return true
  } catch {
    return false
  }
}

// ── Local Storage (safe) ─────────────────────────────────────────────────────
export function lsGet<T>(key: string, fallback: T): T {
  try {
    const v = localStorage.getItem(key)
    return v ? (JSON.parse(v) as T) : fallback
  } catch { return fallback }
}

export function lsSet(key: string, value: unknown): void {
  try { localStorage.setItem(key, JSON.stringify(value)) } catch {}
}

// ── Debounce ──────────────────────────────────────────────────────────────────
export function debounce<T extends (...args: unknown[]) => void>(fn: T, ms: number): T {
  let timer: ReturnType<typeof setTimeout>
  return ((...args: unknown[]) => {
    clearTimeout(timer)
    timer = setTimeout(() => fn(...args), ms)
  }) as T
}
