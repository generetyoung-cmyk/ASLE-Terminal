// ─────────────────────────────────────────────────────────────────────────────
// ASLE Terminal — Type Definitions
// Mirrors on-chain structs from ASLE Engine + Supabase schema from dApp.
// ─────────────────────────────────────────────────────────────────────────────

// ── Token (from ASLE dApp launchpad) ─────────────────────────────────────────
// Sourced from Supabase `communities` table (type='project') when ASLE is live,
// and/or GeckoTerminal for supplemental market data.
export interface LaunchedToken {
  // Identity
  contractAddress: string        // on-chain ERC-20 address (from communities.contract_address)
  name:            string
  symbol:          string
  logoUrl:         string        // from communities.logo_url or IPFS metadata
  bannerUrl:       string
  description:     string

  // Market data (from GeckoTerminal or ASLE engine events)
  priceUsd:        number
  priceEth:        number
  priceChangeH1:   number
  priceChangeH6:   number
  priceChange24h:  number
  volume24h:       number
  volumeH1:        number
  marketCap:       number
  fdv:             number
  liquidity:       number        // total reserves in USD
  txns24h:         number
  buys24h:         number
  sells24h:        number
  holdersCount:    number

  // Bonding curve state (ASLE Engine specific, when deployed)
  poolEth:         number        // ETH side of AMM pool
  poolTok:         number        // Token side of AMM pool
  curveProgress:   number        // 0–100 → graduation threshold %
  phase:           EnginePhase   // 0=Seed, 1=Growth, 2=Mature, 3=Graduated

  // Social (from Supabase communities)
  communityId:     number | null
  memberCount:     number
  ownerWallet:     string

  // Metadata
  createdAt:       number        // unix timestamp
  isASLE:          boolean       // true for the native ASLE token itself
  isNew:           boolean       // < 24h old
  isTrending:      boolean
  isGraduating:    boolean       // curve > 80% complete
  topPoolAddress:  string        // GeckoTerminal top pool for OHLCV
}

// ── ASLE Engine State (on-chain, from dashboardView) ─────────────────────────
export interface EngineState {
  isDeployed:    boolean
  spotPrice:     number          // ETH per ASLE (18-decimal normalized)
  twapFast:      number          // 32-slot TWAP
  twapSlow:      number          // 256-slot TWAP
  spotPriceUsd:  number          // spot * ethUsdPrice
  poolEth:       number
  poolTok:       number
  floorPrice:    number
  accBuyback:    number

  supply: {
    total:       number
    burned:      number
    circulating: number
    onBase:      number
    bridged:     number
  }

  fees: {
    buyBps:      number
    sellBps:     number
    effectiveBuy:  number
    effectiveSell: number
    recycleRatio:  number
  }

  state: {
    trading:     boolean
    paused:      boolean
    circuitBroken: boolean
    limitsOn:    boolean
    lpLocked:    boolean
    lpUnlockAt:  Date | null
    paramsFrozen:boolean
    phase:       EnginePhase
  }

  ema: {
    V:           number          // volume EMA (normalized)
    D:           number          // direction EMA
    sigma:       number          // adaptive volatility estimate
  }

  bridge: {
    activeChains: number
  }

  lastUpdate: number
}

// ── Price Decomposition (ASLE adaptive pricing model) ────────────────────────
export interface PriceDecomposition {
  P0:    number   // base bonding-curve price
  T1:    number   // supply sensitivity multiplier
  T2:    number   // buy-EMA pressure amplifier
  T3:    number   // sell-EMA damper
  composed: number  // final composed price
  params: {
    alpha: number
    beta:  number
    gamma: number
  }
  ema: {
    V:     number
    D:     number
    sigma: number
  }
  phase: EnginePhase
}

// ── Trade Quote ───────────────────────────────────────────────────────────────
export interface BuyQuote {
  tokensOut:       bigint
  tokensOutFmt:    string        // human-readable
  price:           bigint
  priceFmt:        string
  feeBps:          number
  feeTokens:       bigint
  priceImpactBps:  number
  priceImpactPct:  string
  recycleTokens:   bigint
  burnTokens:      bigint
  wouldHitCap:     boolean
}

export interface SellQuote {
  ethOut:          bigint
  ethOutFmt:       string
  price:           bigint
  priceFmt:        string
  feeBps:          number
  priceImpactBps:  number
  priceImpactPct:  string
  wouldHitFloor:   boolean
  wouldHitCap:     boolean
  emergencyFee:    bigint
}

// ── Wallet Info ───────────────────────────────────────────────────────────────
export interface WalletInfo {
  address:     string
  balanceAsle: bigint
  balanceEth:  bigint
  balanceAsleFmt: string
  balanceEthFmt:  string
  valueUsd:    number
  pctOfSupply: string
  tier:        HolderTier
  tierLabel:   string
  feeExempt:   boolean
  limitExempt: boolean
  sellFeePct:  string
  maxCanBuy:   bigint
  maxCanSell:  bigint
}

// ── Candlestick ───────────────────────────────────────────────────────────────
export interface CandleData {
  time:   number   // unix ms
  open:   number
  high:   number
  low:    number
  close:  number
  volume: number   // in USD
  // ASLE-specific overlays (populated when engine deployed)
  twap?:  number
  ema?:   number
}

// ── Orderbook Level (bonding-curve depth simulation) ─────────────────────────
export interface DepthLevel {
  price:      number
  sizeEth:    number   // ETH to buy at this level (asks) or ETH received (bids)
  sizeTok:    number   // tokens received (asks) or tokens to sell (bids)
  total:      number   // cumulative ETH
  pct:        number   // depth bar width 0–100
}

export interface CurveDepth {
  asks: DepthLevel[]   // simulated — how much ETH to pay for progressively more tokens
  bids: DepthLevel[]   // simulated — how much ETH received for progressively more tokens sold
  spread:     number   // in ETH
  spreadPct:  number
  midPrice:   number
}

// ── On-chain Trade Event ──────────────────────────────────────────────────────
export interface TradeEvent {
  id:        string    // tx hash + log index
  txHash:    string
  wallet:    string
  side:      "buy" | "sell"
  ethAmt:    number
  tokAmt:    number
  price:     number    // in ETH
  priceUsd:  number
  feeBps:    number
  timestamp: number
  blockNum:  number
}

// ── Enums ─────────────────────────────────────────────────────────────────────
export type EnginePhase = 0 | 1 | 2 | 3   // Seed | Growth | Mature | Graduated
export type HolderTier  = 0 | 1 | 2 | 3   // Basic | Silver | Gold | Platinum

export const PHASE_LABELS: Record<EnginePhase, string> = {
  0: "Seed",
  1: "Growth",
  2: "Mature",
  3: "Graduated",
}

export const TIER_LABELS: Record<HolderTier, string> = {
  0: "Basic",
  1: "Silver",
  2: "Gold",
  3: "Platinum",
}

export const TIER_COLORS: Record<HolderTier, string> = {
  0: "#4A5568",
  1: "#8B949E",
  2: "#C4A35A",
  3: "#8B5CF6",
}

// ── Sort / Filter ──────────────────────────────────────────────────────────────
export type TokenSortKey = "volume" | "marketCap" | "priceChange" | "liquidity" | "age" | "curveProgress"
export type TokenFilter   = "all" | "new" | "trending" | "graduating"

// ── GeckoTerminal pool data ───────────────────────────────────────────────────
export interface GTPool {
  address:     string
  name:        string
  dexId:       string
  reserveUsd:  number
  volume24h:   number
  priceUsd:    number
  priceChange24h: number
}

// ── Supabase community row ────────────────────────────────────────────────────
export interface SBCommunity {
  id:               number
  name:             string
  type:             string         // "project" | "general" | ...
  desc:             string
  members:          number
  is_private:       boolean
  logo_url:         string
  banner_url:       string
  contract_address: string         // launched token contract
  owner_wallet:     string
  created_at:       string
}
