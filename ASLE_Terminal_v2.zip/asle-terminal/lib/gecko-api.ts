// ─────────────────────────────────────────────────────────────────────────────
// ASLE Terminal — GeckoTerminal API Client
// All calls go through this module. No direct fetch() calls in components.
// Rate limit: ~30 req/min on free tier. Responses are cached with TTL.
// ─────────────────────────────────────────────────────────────────────────────

import { GT_BASE_URL, GT_NETWORK } from "./config"
import type { CandleData, GTPool } from "./types"

const TIMEOUT_MS = 10_000

// ── Simple in-memory cache ────────────────────────────────────────────────────
const _cache = new Map<string, { data: unknown; expiresAt: number }>()

function cached<T>(key: string, ttlMs: number, fetcher: () => Promise<T>): Promise<T> {
  const hit = _cache.get(key)
  if (hit && Date.now() < hit.expiresAt) return Promise.resolve(hit.data as T)
  return fetcher().then(data => {
    _cache.set(key, { data, expiresAt: Date.now() + ttlMs })
    return data
  })
}

async function gt<T>(path: string, ttlMs = 15_000): Promise<T | null> {
  try {
    const res = await fetch(`${GT_BASE_URL}${path}`, {
      signal: AbortSignal.timeout(TIMEOUT_MS),
      headers: { Accept: "application/json" },
    })
    if (!res.ok) return null
    return await res.json() as T
  } catch { return null }
}

// ── Token info ────────────────────────────────────────────────────────────────
export interface GTTokenInfo {
  address:          string
  name:             string
  symbol:           string
  priceUsd:         number
  priceEth:         number
  priceChange1h:    number
  priceChange6h:    number
  priceChange24h:   number
  volume24h:        number
  fdv:              number
  marketCap:        number
  imageUrl:         string
  topPoolAddress:   string
  liquidity:        number
  txns24h:          number
  buys24h:          number
  sells24h:         number
}

export async function fetchTokenInfo(address: string): Promise<GTTokenInfo | null> {
  return cached(`token:${address}`, 20_000, async () => {
    const json = await gt<Record<string, unknown>>(
      `/networks/${GT_NETWORK}/tokens/${address.toLowerCase()}`
    )
    if (!json) return null
    const a = (json as { data?: { attributes?: Record<string, unknown>; relationships?: Record<string, unknown> } }).data?.attributes || {}
    const rels = (json as { data?: { relationships?: Record<string, unknown> } }).data?.relationships || {}
    return {
      address,
      name:           (a.name as string)   || "",
      symbol:         (a.symbol as string) || "",
      priceUsd:       parseFloat((a.price_usd as string) || "0"),
      priceEth:       parseFloat((a.price_usd as string) || "0") / 3000, // approx, updated in hook
      priceChange1h:  parseFloat(((a.price_change_percentage as Record<string, string>)?.h1 ) || "0"),
      priceChange6h:  parseFloat(((a.price_change_percentage as Record<string, string>)?.h6 ) || "0"),
      priceChange24h: parseFloat(((a.price_change_percentage as Record<string, string>)?.h24) || "0"),
      volume24h:      parseFloat(((a.volume_usd as Record<string, string>)?.h24) || "0"),
      fdv:            parseFloat((a.fdv_usd as string)         || "0"),
      marketCap:      parseFloat((a.market_cap_usd as string)  || "0"),
      imageUrl:       (a.image_url as string) || "",
      liquidity:      parseFloat((a.total_reserve_in_usd as string) || "0"),
      txns24h:        0,
      buys24h:        0,
      sells24h:       0,
      topPoolAddress: (rels?.top_pool?.data as { id: string } | null)?.id?.split("_").pop() || "",
    } as GTTokenInfo
  })
}

// ── Token pools ───────────────────────────────────────────────────────────────
export async function fetchTokenPools(address: string): Promise<GTPool[]> {
  return cached(`pools:${address}`, 30_000, async () => {
    const json = await gt<Record<string, unknown>>(
      `/networks/${GT_NETWORK}/tokens/${address.toLowerCase()}/pools?page=1&sort=h24_volume_usd_liquidity_score`
    )
    if (!json) return []
    const pools = ((json as { data?: unknown[] }).data || []) as Array<Record<string, unknown>>
    return pools.slice(0, 5).map(p => {
      const a = (p.attributes || {}) as Record<string, unknown>
      return {
        address:        (p.id as string)?.split("_").pop() || "",
        name:           (a.name as string) || "",
        dexId:          (a.dex_id as string) || "",
        reserveUsd:     parseFloat((a.reserve_in_usd as string) || "0"),
        volume24h:      parseFloat(((a.volume_usd as Record<string, string>)?.h24) || "0"),
        priceUsd:       parseFloat((a.base_token_price_usd as string) || "0"),
        priceChange24h: parseFloat(((a.price_change_percentage as Record<string, string>)?.h24) || "0"),
      } as GTPool
    })
  })
}

// ── OHLCV (candlestick data) ──────────────────────────────────────────────────
export type OHLCVTimeframe = "minute" | "hour" | "day"

export async function fetchOHLCV(
  poolAddress: string,
  timeframe: OHLCVTimeframe = "hour",
  aggregate = 1,
  limit = 300,
): Promise<CandleData[]> {
  if (!poolAddress) return []
  const key = `ohlcv:${poolAddress}:${timeframe}:${aggregate}`
  return cached(key, timeframe === "minute" ? 30_000 : 60_000, async () => {
    const json = await gt<Record<string, unknown>>(
      `/networks/${GT_NETWORK}/pools/${poolAddress.toLowerCase()}/ohlcv/${timeframe}?aggregate=${aggregate}&limit=${limit}&currency=usd&token=base`
    )
    if (!json) return []
    const ohlcv = ((json as { data?: { attributes?: { ohlcv_list?: unknown[] } } }).data?.attributes?.ohlcv_list || []) as [number, number, number, number, number, number][]
    // GT returns [timestamp, open, high, low, close, volume]
    return ohlcv.map(([ts, o, h, l, c, v]) => ({
      time:   ts * 1000,  // convert to ms
      open:   o,
      high:   h,
      low:    l,
      close:  c,
      volume: v,
    })).sort((a, b) => a.time - b.time)
  })
}

// ── Token list (Base network trending + new) ──────────────────────────────────
export interface GTTokenListItem {
  address:       string
  name:          string
  symbol:        string
  priceUsd:      number
  priceChange24h:number
  volume24h:     number
  fdv:           number
  marketCap:     number
  imageUrl:      string
  liquidity:     number
  topPoolAddress:string
}

export async function fetchNewTokens(page = 1): Promise<GTTokenListItem[]> {
  return cached(`new-tokens:${page}`, 30_000, async () => {
    const json = await gt<Record<string, unknown>>(
      `/networks/${GT_NETWORK}/new_pools?page=${page}&include=base_token`
    )
    if (!json) return []
    const pools = ((json as { data?: unknown[] }).data || []) as Array<Record<string, unknown>>
    const included = ((json as { included?: unknown[] }).included || []) as Array<Record<string, unknown>>

    const tokenMap = new Map<string, Record<string, unknown>>()
    for (const inc of included) {
      if ((inc.type as string) === "token") tokenMap.set(inc.id as string, (inc.attributes || {}) as Record<string, unknown>)
    }

    return pools.slice(0, 50).map(p => {
      const a = (p.attributes || {}) as Record<string, unknown>
      const tokenRel = ((p.relationships as Record<string, unknown>)?.base_token as { data: { id: string } })?.data
      const tokAttrs = tokenRel ? tokenMap.get(tokenRel.id) || {} : {}
      const addr = (tokAttrs.address as string) || tokenRel?.id?.replace(`${GT_NETWORK}_`, "") || ""
      return {
        address:        addr,
        name:           (tokAttrs.name as string)   || ((a.name as string) || "").split(" / ")[0] || "Unknown",
        symbol:         (tokAttrs.symbol as string) || "",
        priceUsd:       parseFloat((a.base_token_price_usd as string) || "0"),
        priceChange24h: parseFloat(((a.price_change_percentage as Record<string, string>)?.h24) || "0"),
        volume24h:      parseFloat(((a.volume_usd as Record<string, string>)?.h24) || "0"),
        fdv:            parseFloat((a.fdv_usd as string) || "0"),
        marketCap:      0,
        imageUrl:       (tokAttrs.image_url as string) || "",
        liquidity:      parseFloat((a.reserve_in_usd as string) || "0"),
        topPoolAddress: (p.id as string)?.split("_").pop() || "",
      } as GTTokenListItem
    }).filter(t => t.address && t.priceUsd > 0)
  })
}

export async function fetchTrendingPools(page = 1): Promise<GTTokenListItem[]> {
  return cached(`trending:${page}`, 30_000, async () => {
    const json = await gt<Record<string, unknown>>(
      `/networks/${GT_NETWORK}/trending_pools?page=${page}&include=base_token`
    )
    if (!json) return []
    const pools = ((json as { data?: unknown[] }).data || []) as Array<Record<string, unknown>>
    const included = ((json as { included?: unknown[] }).included || []) as Array<Record<string, unknown>>

    const tokenMap = new Map<string, Record<string, unknown>>()
    for (const inc of included) {
      if ((inc.type as string) === "token") tokenMap.set(inc.id as string, (inc.attributes || {}) as Record<string, unknown>)
    }

    return pools.slice(0, 50).map(p => {
      const a = (p.attributes || {}) as Record<string, unknown>
      const tokenRel = ((p.relationships as Record<string, unknown>)?.base_token as { data: { id: string } })?.data
      const tokAttrs = tokenRel ? tokenMap.get(tokenRel.id) || {} : {}
      const addr = (tokAttrs.address as string) || tokenRel?.id?.replace(`${GT_NETWORK}_`, "") || ""
      return {
        address:        addr,
        name:           (tokAttrs.name as string)   || "",
        symbol:         (tokAttrs.symbol as string) || "",
        priceUsd:       parseFloat((a.base_token_price_usd as string) || "0"),
        priceChange24h: parseFloat(((a.price_change_percentage as Record<string, string>)?.h24) || "0"),
        volume24h:      parseFloat(((a.volume_usd as Record<string, string>)?.h24) || "0"),
        fdv:            parseFloat((a.fdv_usd as string) || "0"),
        marketCap:      0,
        imageUrl:       (tokAttrs.image_url as string) || "",
        liquidity:      parseFloat((a.reserve_in_usd as string) || "0"),
        topPoolAddress: (p.id as string)?.split("_").pop() || "",
      } as GTTokenListItem
    }).filter(t => t.address && t.priceUsd > 0)
  })
}

// ── Search tokens on Base ─────────────────────────────────────────────────────
export async function searchTokens(query: string): Promise<GTTokenListItem[]> {
  if (query.length < 2) return []
  const json = await gt<Record<string, unknown>>(
    `/search?query=${encodeURIComponent(query)}&network=${GT_NETWORK}`
  )
  if (!json) return []
  const pools = ((json as { data?: unknown[] }).data || []) as Array<Record<string, unknown>>
  return pools.slice(0, 20).map(p => {
    const a = (p.attributes || {}) as Record<string, unknown>
    const addr = (p.id as string)?.split("_")[1] || ""
    return {
      address:        addr,
      name:           ((a.name as string) || "").split(" / ")[0] || "Unknown",
      symbol:         ((a.name as string) || "").split(" / ")[0] || "?",
      priceUsd:       parseFloat((a.base_token_price_usd as string) || "0"),
      priceChange24h: parseFloat(((a.price_change_percentage as Record<string, string>)?.h24) || "0"),
      volume24h:      parseFloat(((a.volume_usd as Record<string, string>)?.h24) || "0"),
      fdv:            parseFloat((a.fdv_usd as string) || "0"),
      marketCap:      0,
      imageUrl:       "",
      liquidity:      parseFloat((a.reserve_in_usd as string) || "0"),
      topPoolAddress: (p.id as string)?.split("_").pop() || "",
    } as GTTokenListItem
  }).filter(t => t.address)
}

// ── ETH/USD price ─────────────────────────────────────────────────────────────
const ETH_WETH_BASE = "0x4200000000000000000000000000000000000006"

export async function fetchEthUsd(): Promise<number> {
  return cached("eth-usd", 30_000, async () => {
    const json = await gt<Record<string, unknown>>(
      `/networks/${GT_NETWORK}/tokens/${ETH_WETH_BASE}`
    )
    if (!json) return 3000
    const a = ((json as { data?: { attributes?: Record<string, unknown> } }).data?.attributes || {}) as Record<string, unknown>
    return parseFloat((a.price_usd as string) || "3000") || 3000
  })
}
