# ASLE Terminal

Professional trading terminal for the ASLE ecosystem on Base Mainnet.
Modeled after Axiom / pump.fun terminal — built specifically for tokens launched through the ASLE dApp.

---

## Architecture

```
ASLE Terminal
├── Token data sources
│   ├── Primary:   ASLE dApp Supabase (communities table, type='project')
│   └── Secondary: GeckoTerminal Base network (trending + new pools)
│
├── Price / trading engine
│   └── ASLE Engine contracts (ASLE_Core + ASLE_Views on Base Mainnet)
│
└── Wallet
    └── MetaMask / EIP-1193 providers — Base Mainnet (chainId 8453)
```

---

## Pre-launch vs Post-launch

The terminal is designed to run in **two modes**:

### Pre-launch (engine not deployed)
- Token list is populated from GeckoTerminal Base trending/new pools
- If ASLE dApp Supabase has project communities, those appear first with a ✓ badge
- Chart data comes from GeckoTerminal OHLCV
- Order entry shows a "coming soon" state — no trading is possible
- Wallet connect works (for future use)

### Post-launch (engine deployed)
Activate by setting env vars in `.env.local`:
```
NEXT_PUBLIC_ASLE_CORE=0x...
NEXT_PUBLIC_ASLE_VIEWS=0x...
NEXT_PUBLIC_ASLE_ORACLE=0x...
```
- `dashboardView()` is polled every 12s for live price, fees, pool state, circuit breaker
- `simulateBuy` / `simulateSell` power the real-time quote panel
- `walletInfo()` fetches holder tier, fee exemption, max trade sizes
- `priceDecomposition()` populates the Engine tab in token info
- AMM depth is simulated from live `poolEth` / `poolTok`
- Buy / sell execute through `ASLE_Core.buy()` / `ASLE_Core.sell()`

---

## Token Source Priority

1. **ASLE dApp Supabase** — communities with `type='project'` and a non-zero `contract_address`
   These are tokens launched through the ASLE dApp launchpad.
   They appear with a teal ✓ badge.

2. **GeckoTerminal Base** — trending pools + new pools
   Fills the list with real Base network tokens for a live, data-rich experience
   even before the ASLE launchpad has many launches.

---

## Integration with ASLE dApp

The terminal reads from the same Supabase project as the dApp.
No write access is needed — it only reads:
```
GET /rest/v1/communities?type=eq.project&select=*
```

When a user launches a token in the dApp:
1. `createProjectCommunity()` inserts a row in `communities` with `type='project'` and `contract_address`
2. Terminal picks it up on next poll (60s interval, or on manual refresh)
3. Token appears at the top of the "All" list sorted by creation time

---

## Local Development

```bash
cp .env.example .env.local
npm install
npm run dev
```

Open `http://localhost:3000`.

Without env vars, the terminal runs in pre-launch mode.
For full testing, deploy ASLE Engine to a testnet and set the addresses.

---

## Deployment (Cloudflare Pages / Vercel)

```bash
npm run build
```

Set the env vars in your deployment dashboard.
No server-side secrets needed — all reads are public RPC + GeckoTerminal + Supabase anon key.

---

## Roadmap (post-launch additions)

- [ ] WalletConnect v2 deep-link support (Reown AppKit, same as dApp)
- [ ] On-chain trade history via event log indexer
- [ ] Price alerts (localStorage + push notification)
- [ ] ASLE bridge status panel (OFT adapter, remote chains)
- [ ] Holder leaderboard (from walletInfo tier data)
- [ ] Token social feed (link to dApp community room)
