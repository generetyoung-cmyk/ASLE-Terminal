"use client"

import { useEffect } from "react"
import {
  PanelGroup, Panel, PanelResizeHandle,
} from "react-resizable-panels"

import { useWallet }        from "@/hooks/use-wallet"
import { useASLEEngine }    from "@/hooks/use-asle-engine"
import { useTokenList }     from "@/hooks/use-token-list"
import { useSelectedToken } from "@/hooks/use-selected-token"

import TerminalHeader  from "@/components/terminal/TerminalHeader"
import MarketSidebar   from "@/components/terminal/MarketSidebar"
import TradingChart    from "@/components/chart/TradingChart"
import Orderbook       from "@/components/terminal/Orderbook"
import RecentTrades    from "@/components/terminal/RecentTrades"
import OrderEntry      from "@/components/terminal/OrderEntry"
import TokenInfoPanel  from "@/components/terminal/TokenInfoPanel"
import PositionsPanel  from "@/components/terminal/PositionsPanel"

export default function TerminalPage() {
  const wallet      = useWallet()
  const engineHook  = useASLEEngine()
  const tokenList   = useTokenList()
  const { selectedToken, setSelectedToken } = tokenList

  // Selected token data — chart, depth, trades
  const { candles, trades, depth, timeframe, setTimeframe, isLoading: chartLoading, curveProgress } =
    useSelectedToken(
      selectedToken,
      engineHook.engine?.poolEth || 0,
      engineHook.engine?.poolTok || 0,
    )

  // Sync ASLE native token into engine when deployed
  const engine = engineHook.engine

  return (
    <div
      className="flex flex-col h-screen w-screen overflow-hidden"
      style={{ background: "var(--bg-base)" }}
    >
      {/* ── Header ─────────────────────────────────────────────────────── */}
      <TerminalHeader
        token={selectedToken}
        engine={engine}
        ethUsd={engineHook.ethUsd}
        wallet={wallet}
        isEngineDeployed={engineHook.isDeployed}
      />

      {/* ── Body ───────────────────────────────────────────────────────── */}
      <div className="flex-1 overflow-hidden">
        <PanelGroup direction="horizontal" autoSaveId="asle-terminal-h">

          {/* ── Col 1: Token list ──────────────────────────────────────── */}
          <Panel defaultSize={14} minSize={10} maxSize={22}>
            <MarketSidebar hook={tokenList} />
          </Panel>
          <PanelResizeHandle />

          {/* ── Col 2: Chart + Positions ───────────────────────────────── */}
          <Panel defaultSize={55} minSize={35}>
            <PanelGroup direction="vertical" autoSaveId="asle-terminal-v-main">

              {/* Chart */}
              <Panel defaultSize={70} minSize={40}>
                <TradingChart
                  candles={candles}
                  isLoading={chartLoading}
                  timeframe={timeframe}
                  onTimeframeChange={setTimeframe}
                  twapPrice={engine ? engine.twapFast * engineHook.ethUsd : undefined}
                  emaPrice={undefined}
                  symbol={selectedToken?.symbol || ""}
                />
              </Panel>
              <PanelResizeHandle />

              {/* Positions / Trades */}
              <Panel defaultSize={30} minSize={20}>
                <PanelGroup direction="horizontal" autoSaveId="asle-terminal-h-bottom">
                  <Panel defaultSize={55} minSize={30}>
                    <PositionsPanel
                      wallet={wallet}
                      engineHook={engineHook}
                      ethUsd={engineHook.ethUsd}
                    />
                  </Panel>
                  <PanelResizeHandle />
                  <Panel defaultSize={45} minSize={30}>
                    <RecentTrades
                      trades={trades}
                      symbol={selectedToken?.symbol || "—"}
                    />
                  </Panel>
                </PanelGroup>
              </Panel>
            </PanelGroup>
          </Panel>
          <PanelResizeHandle />

          {/* ── Col 3: Orderbook ───────────────────────────────────────── */}
          <Panel defaultSize={12} minSize={10} maxSize={20}>
            <Orderbook
              depth={depth}
              symbol={selectedToken?.symbol || "—"}
              priceUsd={selectedToken?.priceUsd || 0}
            />
          </Panel>
          <PanelResizeHandle />

          {/* ── Col 4: Token info + Order entry ────────────────────────── */}
          <Panel defaultSize={19} minSize={16} maxSize={28}>
            <PanelGroup direction="vertical" autoSaveId="asle-terminal-v-right">
              <Panel defaultSize={50} minSize={30}>
                <TokenInfoPanel
                  token={selectedToken}
                  engine={engine}
                  decomp={engineHook.decomp}
                  ethUsd={engineHook.ethUsd}
                  isEngineDeployed={engineHook.isDeployed}
                  curveProgress={curveProgress}
                />
              </Panel>
              <PanelResizeHandle />
              <Panel defaultSize={50} minSize={30}>
                <OrderEntry
                  token={selectedToken}
                  engine={engine}
                  engineHook={engineHook}
                  wallet={wallet}
                  ethUsd={engineHook.ethUsd}
                />
              </Panel>
            </PanelGroup>
          </Panel>

        </PanelGroup>
      </div>
    </div>
  )
}
