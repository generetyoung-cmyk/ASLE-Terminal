"use client"

import { cn, fmtPrice, fmtTokens, fmtEth, fmtTime } from "@/lib/utils"
import type { TradeEvent } from "@/lib/types"

interface RecentTradesProps {
  trades: TradeEvent[]
  symbol: string
}

export default function RecentTrades({ trades, symbol }: RecentTradesProps) {
  return (
    <div className="flex flex-col h-full" style={{ background: "var(--bg-panel)" }}>
      {/* Header */}
      <div className="panel-header">
        <span className="panel-label">Trades</span>
        <div className="ml-auto flex items-center gap-1">
          <div className="status-dot online" style={{ width: "5px", height: "5px" }} />
          <span className="font-mono text-[9px]" style={{ color: "var(--text-faint)" }}>Live</span>
        </div>
      </div>

      {/* Column headers */}
      <div
        className="grid px-2 py-1 border-b text-[9px] font-mono uppercase"
        style={{
          gridTemplateColumns: "1fr 1fr 1fr",
          borderColor: "var(--border-dim)",
          color: "var(--text-dim)",
        }}
      >
        <span>Price</span>
        <span className="text-right">{symbol}</span>
        <span className="text-right">Time</span>
      </div>

      {/* Trade list */}
      <div className="flex-1 overflow-y-auto">
        {trades.length === 0 ? (
          <div className="flex items-center justify-center h-20">
            <span className="font-mono text-[10px]" style={{ color: "var(--text-dim)" }}>
              Waiting for trades…
            </span>
          </div>
        ) : (
          trades.map((trade, i) => (
            <TradeRow key={trade.id} trade={trade} index={i} />
          ))
        )}
      </div>
    </div>
  )
}

function TradeRow({ trade, index }: { trade: TradeEvent; index: number }) {
  const isBuy = trade.side === "buy"
  return (
    <div
      className={cn(
        "grid px-2 py-[3px] hover:bg-[var(--bg-hover)] transition-colors",
        index === 0 && "animate-slide-in",
      )}
      style={{ gridTemplateColumns: "1fr 1fr 1fr" }}
    >
      <span
        className={cn("font-mono text-[10px] tabular-nums", isBuy ? "price-up" : "price-down")}
      >
        ${fmtPrice(trade.priceUsd || trade.price)}
      </span>
      <span
        className="font-mono text-[10px] tabular-nums text-right"
        style={{ color: "var(--text-secondary)" }}
      >
        {fmtTokens(trade.tokAmt)}
      </span>
      <span
        className="font-mono text-[10px] tabular-nums text-right"
        style={{ color: "var(--text-dim)" }}
      >
        {fmtTime(trade.timestamp)}
      </span>
    </div>
  )
}
