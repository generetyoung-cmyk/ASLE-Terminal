"use client"

import { cn, fmtEth, fmtTokens, fmtPrice } from "@/lib/utils"
import type { CurveDepth } from "@/lib/types"

interface OrderbookProps {
  depth:  CurveDepth | null
  symbol: string
  priceUsd: number
}

export default function Orderbook({ depth, symbol, priceUsd }: OrderbookProps) {
  return (
    <div className="flex flex-col h-full" style={{ background: "var(--bg-panel)" }}>
      {/* Header */}
      <div className="panel-header">
        <span className="panel-label">Depth</span>
        {depth && (
          <span
            className="ml-auto font-mono text-[9px]"
            style={{ color: "var(--text-dim)" }}
          >
            AMM Simulated
          </span>
        )}
      </div>

      {!depth ? (
        <NoCurveState />
      ) : (
        <>
          {/* Spread */}
          <div
            className="flex items-center justify-between px-2 py-1 border-b"
            style={{ borderColor: "var(--border-dim)" }}
          >
            <span className="font-mono text-[9px]" style={{ color: "var(--text-dim)" }}>
              Spread
            </span>
            <div className="flex items-center gap-2">
              <span className="font-mono text-[10px]" style={{ color: "var(--text-secondary)" }}>
                {fmtEth(depth.spread, 6)}
              </span>
              <span className="font-mono text-[9px]" style={{ color: "var(--text-dim)" }}>
                ({depth.spreadPct.toFixed(3)}%)
              </span>
            </div>
          </div>

          {/* Column headers */}
          <div
            className="grid grid-cols-3 px-2 py-1 border-b"
            style={{ borderColor: "var(--border-dim)" }}
          >
            {["Price (ETH)", "Size (ETH)", `Size (${symbol})`].map((h, i) => (
              <span
                key={i}
                className={cn("font-mono text-[9px] uppercase", i > 0 && "text-right")}
                style={{ color: "var(--text-dim)" }}
              >
                {h}
              </span>
            ))}
          </div>

          {/* Asks (sell pressure / cost to buy) */}
          <div className="flex-1 overflow-y-auto flex flex-col-reverse">
            {depth.asks.slice(0, 14).map((level, i) => (
              <div key={i} className="relative group">
                <div
                  className="absolute inset-y-0 right-0 depth-bar-ask"
                  style={{ width: `${level.pct}%` }}
                />
                <div className="relative grid grid-cols-3 px-2 py-[3px] hover:bg-[var(--bg-hover)] transition-colors">
                  <span className="font-mono text-[10px] price-down tabular-nums">
                    {fmtPrice(level.price)}
                  </span>
                  <span className="font-mono text-[10px] tabular-nums text-right" style={{ color: "var(--text-secondary)" }}>
                    {level.sizeEth.toFixed(4)}
                  </span>
                  <span className="font-mono text-[10px] tabular-nums text-right" style={{ color: "var(--text-dim)" }}>
                    {fmtTokens(level.sizeTok)}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Mid price */}
          <div
            className="flex items-center justify-between px-2 py-1.5 border-y"
            style={{ borderColor: "var(--border-std)", background: "var(--bg-surface)" }}
          >
            <span className="font-mono text-[11px] font-bold" style={{ color: "var(--text-primary)" }}>
              {fmtPrice(depth.midPrice)}
            </span>
            <span className="font-mono text-[10px]" style={{ color: "var(--text-secondary)" }}>
              ${fmtPrice(depth.midPrice * (priceUsd / depth.midPrice))}
            </span>
          </div>

          {/* Bids (buy support / ETH received for sells) */}
          <div className="flex-1 overflow-y-auto">
            {depth.bids.slice(0, 14).map((level, i) => (
              <div key={i} className="relative group">
                <div
                  className="absolute inset-y-0 right-0 depth-bar-bid"
                  style={{ width: `${level.pct}%` }}
                />
                <div className="relative grid grid-cols-3 px-2 py-[3px] hover:bg-[var(--bg-hover)] transition-colors">
                  <span className="font-mono text-[10px] price-up tabular-nums">
                    {fmtPrice(level.price)}
                  </span>
                  <span className="font-mono text-[10px] tabular-nums text-right" style={{ color: "var(--text-secondary)" }}>
                    {level.sizeEth.toFixed(4)}
                  </span>
                  <span className="font-mono text-[10px] tabular-nums text-right" style={{ color: "var(--text-dim)" }}>
                    {fmtTokens(level.sizeTok)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}

function NoCurveState() {
  return (
    <div className="flex-1 flex flex-col items-center justify-center gap-2 px-4 text-center">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--text-faint)" strokeWidth="1">
        <path d="M3 3v18h18" /><path d="m19 9-5 5-4-4-3 3" />
      </svg>
      <span className="font-mono text-[10px]" style={{ color: "var(--text-dim)" }}>
        Depth available after<br />ASLE Engine launch
      </span>
    </div>
  )
}
