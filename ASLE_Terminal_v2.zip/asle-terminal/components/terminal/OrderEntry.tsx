"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { cn, fmtPrice, fmtEth, fmtTokens, debounce } from "@/lib/utils"
import { BASE_EXPLORER, isEngineDeployed } from "@/lib/config"
import type { LaunchedToken, EngineState, BuyQuote, SellQuote } from "@/lib/types"
import type { WalletHook } from "@/hooks/use-wallet"
import type { ASLEEngineHook } from "@/hooks/use-asle-engine"

interface OrderEntryProps {
  token:    LaunchedToken | null
  engine:   EngineState  | null
  engineHook: ASLEEngineHook
  wallet:   WalletHook
  ethUsd:   number
}

const SLIPPAGE_PRESETS = [0.5, 1, 2, 5]
const ETH_PRESETS      = ["0.05", "0.1", "0.25", "0.5", "1.0"]
const PCT_PRESETS      = [25, 50, 75, 100]

type Side = "buy" | "sell"
type Status = "idle" | "quoting" | "confirming" | "pending" | "success" | "error"

export default function OrderEntry({
  token, engine, engineHook, wallet, ethUsd,
}: OrderEntryProps) {
  const [side,      setSide]      = useState<Side>("buy")
  const [ethAmt,    setEthAmt]    = useState("")
  const [tokAmt,    setTokAmt]    = useState("")
  const [slippage,  setSlippage]  = useState(1)
  const [customSlip,setCustomSlip]= useState("")
  const [buyQuote,  setBuyQuote]  = useState<BuyQuote  | null>(null)
  const [sellQuote, setSellQuote] = useState<SellQuote | null>(null)
  const [status,    setStatus]    = useState<Status>("idle")
  const [txHash,    setTxHash]    = useState<string | null>(null)
  const [errMsg,    setErrMsg]    = useState<string | null>(null)

  const deployed = isEngineDeployed()

  // ── Quote (debounced) ────────────────────────────────────────────────────
  const debouncedQuoteBuy  = useRef(debounce(async (val: string) => {
    if (!val || parseFloat(val) <= 0) { setBuyQuote(null); return }
    const q = await engineHook.quoteBuy(val)
    setBuyQuote(q)
    setStatus("idle")
  }, 400))

  const debouncedQuoteSell = useRef(debounce(async (val: string) => {
    if (!val || parseFloat(val) <= 0) { setSellQuote(null); return }
    const q = await engineHook.quoteSell(val)
    setSellQuote(q)
    setStatus("idle")
  }, 400))

  useEffect(() => {
    if (!deployed) return
    if (side === "buy"  && ethAmt) { setStatus("quoting"); debouncedQuoteBuy.current(ethAmt)  }
    if (side === "sell" && tokAmt) { setStatus("quoting"); debouncedQuoteSell.current(tokAmt) }
  }, [ethAmt, tokAmt, side, deployed])

  // ── Execute ──────────────────────────────────────────────────────────────
  const handleTrade = useCallback(async () => {
    if (!wallet.isConnected) { wallet.connect(); return }
    if (!wallet.isCorrectChain) { wallet.switchChain(); return }
    if (!deployed || !token) return

    const amt = side === "buy" ? ethAmt : tokAmt
    if (!amt || parseFloat(amt) <= 0) return

    setStatus("confirming")
    setErrMsg(null)
    setTxHash(null)

    try {
      const hash = side === "buy"
        ? await engineHook.executeBuy(amt, slippage, wallet.signer)
        : await engineHook.executeSell(amt, slippage, wallet.signer)

      if (hash) {
        setTxHash(hash)
        setStatus("success")
        setEthAmt("")
        setTokAmt("")
        setBuyQuote(null)
        setSellQuote(null)
        setTimeout(() => setStatus("idle"), 6000)
      } else {
        setStatus("error")
        setErrMsg("Transaction failed or rejected.")
      }
    } catch (err: unknown) {
      const e = err as { message?: string; code?: number }
      setStatus("error")
      if (e?.code === 4001) setErrMsg("Transaction rejected.")
      else setErrMsg(e?.message?.slice(0, 80) || "Transaction failed.")
    }
  }, [side, ethAmt, tokAmt, slippage, deployed, token, wallet, engineHook])

  // ── Sell pct shortcut ────────────────────────────────────────────────────
  const handleSellPct = (pct: number) => {
    if (!wallet.isConnected || !engineHook) return
    // wallet info maxCanSell
    engineHook.getWalletInfo(wallet.address!).then(info => {
      if (!info) return
      const n = Number(info.maxCanSell) / 1e18 * (pct / 100)
      setTokAmt(n.toFixed(4))
    })
  }

  const activeSlippage = customSlip ? parseFloat(customSlip) : slippage
  const quote = side === "buy" ? buyQuote : sellQuote
  const isLoading = status === "quoting"

  return (
    <div className="flex flex-col h-full" style={{ background: "var(--bg-panel)" }}>
      {/* Side toggle */}
      <div
        className="grid grid-cols-2 m-2 rounded overflow-hidden shrink-0"
        style={{ border: "1px solid var(--border-std)" }}
      >
        {(["buy", "sell"] as const).map(s => (
          <button
            key={s}
            onClick={() => setSide(s)}
            className="py-1.5 font-mono font-bold text-xs transition-all uppercase tracking-wide"
            style={{
              background: side === s
                ? s === "buy" ? "var(--teal)" : "var(--red)"
                : "transparent",
              color: side === s
                ? s === "buy" ? "var(--bg-base)" : "#fff"
                : "var(--text-dim)",
            }}
          >
            {s}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-2 pb-2 flex flex-col gap-2">

        {/* Pre-launch notice */}
        {!deployed && (
          <div
            className="rounded p-2.5 text-center"
            style={{
              background: "var(--amber-dim)",
              border: "1px solid rgba(245,158,11,0.2)",
            }}
          >
            <div className="prelaunched-badge mx-auto mb-1">
              <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" />
              </svg>
              ASLE Engine — Pre-Launch
            </div>
            <p className="font-mono text-[10px]" style={{ color: "var(--amber)" }}>
              Trading activates once the ASLE Engine is deployed on Base Mainnet.
            </p>
          </div>
        )}

        {/* Buy — ETH input */}
        {side === "buy" && (
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center justify-between">
              <label className="font-mono text-[10px]" style={{ color: "var(--text-dim)" }}>
                ETH Amount
              </label>
              <span className="font-mono text-[10px]" style={{ color: "var(--text-dim)" }}>
                ETH Presets
              </span>
            </div>
            <input
              type="number"
              min="0"
              step="0.01"
              placeholder="0.00"
              value={ethAmt}
              onChange={e => setEthAmt(e.target.value)}
              disabled={!deployed}
              className="terminal-input text-right"
              style={{ opacity: deployed ? 1 : 0.5 }}
            />
            <div className="grid grid-cols-5 gap-1">
              {ETH_PRESETS.map(p => (
                <button
                  key={p}
                  onClick={() => setEthAmt(p)}
                  disabled={!deployed}
                  className="btn-ghost py-0.5 text-[10px] font-mono"
                  style={{ opacity: deployed ? 1 : 0.5 }}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Sell — token input */}
        {side === "sell" && (
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center justify-between">
              <label className="font-mono text-[10px]" style={{ color: "var(--text-dim)" }}>
                {token?.symbol || "Token"} Amount
              </label>
              <button
                onClick={() => engineHook.getWalletInfo(wallet.address || "").then(i => i && setTokAmt(Number(i.maxCanSell) / 1e18 + ""))}
                className="font-mono text-[10px] transition-colors"
                style={{ color: "var(--teal)" }}
              >
                MAX
              </button>
            </div>
            <input
              type="number"
              min="0"
              step="100"
              placeholder="0.00"
              value={tokAmt}
              onChange={e => setTokAmt(e.target.value)}
              disabled={!deployed}
              className="terminal-input text-right"
              style={{ opacity: deployed ? 1 : 0.5 }}
            />
            <div className="grid grid-cols-4 gap-1">
              {PCT_PRESETS.map(p => (
                <button
                  key={p}
                  onClick={() => handleSellPct(p)}
                  disabled={!deployed || !wallet.isConnected}
                  className="btn-ghost py-0.5 text-[10px] font-mono"
                  style={{ opacity: (deployed && wallet.isConnected) ? 1 : 0.5 }}
                >
                  {p}%
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Quote display */}
        {deployed && (
          <div
            className="rounded p-2 flex flex-col gap-1.5"
            style={{ background: "var(--bg-surface)", border: "1px solid var(--border-dim)" }}
          >
            {isLoading ? (
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full border border-t-transparent border-[var(--teal)] animate-spin" />
                <span className="font-mono text-[10px]" style={{ color: "var(--text-dim)" }}>Quoting…</span>
              </div>
            ) : side === "buy" && buyQuote ? (
              <>
                <QuoteRow label="You receive"    value={`${fmtTokens(Number(buyQuote.tokensOutFmt))} ${token?.symbol || "ASLE"}`} highlight />
                <QuoteRow label="Price"          value={`${buyQuote.priceFmt} ETH`} />
                <QuoteRow label="Fee"            value={`${(buyQuote.feeBps / 100).toFixed(2)}%`} />
                <QuoteRow label="Price impact"   value={buyQuote.priceImpactPct} warn={buyQuote.priceImpactBps > 200} />
                <QuoteRow label="Burn"           value={fmtTokens(Number(BigInt(buyQuote.burnTokens.toString()) / 10n**14n) / 10000)} dim />
                {buyQuote.wouldHitCap && (
                  <div className="font-mono text-[9px] text-center" style={{ color: "var(--amber)" }}>
                    ⚠ Would hit buy cap — reduce amount
                  </div>
                )}
              </>
            ) : side === "sell" && sellQuote ? (
              <>
                <QuoteRow label="You receive"    value={`${fmtEth(Number(sellQuote.ethOutFmt))} ETH`} highlight />
                <QuoteRow label="Price"          value={`${sellQuote.priceFmt} ETH`} />
                <QuoteRow label="Fee"            value={`${(sellQuote.feeBps / 100).toFixed(2)}%`} />
                <QuoteRow label="Price impact"   value={sellQuote.priceImpactPct} warn={sellQuote.priceImpactBps > 200} />
                {sellQuote.wouldHitFloor && (
                  <div className="font-mono text-[9px] text-center" style={{ color: "var(--red)" }}>
                    ⚠ Would hit floor price
                  </div>
                )}
              </>
            ) : (
              <span className="font-mono text-[10px] text-center" style={{ color: "var(--text-faint)" }}>
                Enter an amount to see quote
              </span>
            )}
          </div>
        )}

        {/* Slippage */}
        <div className="flex flex-col gap-1">
          <div className="flex items-center justify-between">
            <span className="font-mono text-[10px]" style={{ color: "var(--text-dim)" }}>Slippage</span>
            <span className="font-mono text-[10px]" style={{ color: "var(--teal)" }}>
              {activeSlippage.toFixed(1)}%
            </span>
          </div>
          <div className="flex items-center gap-1">
            {SLIPPAGE_PRESETS.map(p => (
              <button
                key={p}
                onClick={() => { setSlippage(p); setCustomSlip("") }}
                className={cn(
                  "flex-1 py-0.5 rounded font-mono text-[10px] transition-colors",
                  slippage === p && !customSlip
                    ? "bg-[var(--teal-dim)] text-[var(--teal)]"
                    : "text-[var(--text-dim)] hover:text-[var(--text-secondary)]",
                )}
                style={{ border: "1px solid var(--border-dim)" }}
              >
                {p}%
              </button>
            ))}
            <input
              type="number"
              min="0.1"
              max="50"
              step="0.1"
              placeholder="Custom"
              value={customSlip}
              onChange={e => setCustomSlip(e.target.value)}
              className="flex-1 text-center rounded font-mono text-[10px] outline-none"
              style={{
                background: customSlip ? "var(--teal-dim)" : "var(--bg-surface)",
                border: `1px solid ${customSlip ? "var(--teal)" : "var(--border-dim)"}`,
                color: customSlip ? "var(--teal)" : "var(--text-dim)",
                padding: "2px 4px",
              }}
            />
          </div>
        </div>

        {/* Status feedback */}
        {status === "success" && txHash && (
          <div
            className="rounded p-2 flex items-center gap-2"
            style={{ background: "var(--teal-dim)", border: "1px solid rgba(0,212,170,0.2)" }}
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--teal)" strokeWidth="2.5">
              <polyline points="20 6 9 17 4 12" />
            </svg>
            <span className="font-mono text-[10px]" style={{ color: "var(--teal)" }}>
              Confirmed!{" "}
              <a
                href={`${BASE_EXPLORER}/tx/${txHash}`}
                target="_blank" rel="noopener noreferrer"
                className="underline"
              >
                View tx
              </a>
            </span>
          </div>
        )}

        {status === "error" && errMsg && (
          <div
            className="rounded p-2"
            style={{ background: "var(--red-dim)", border: "1px solid rgba(246,70,93,0.2)" }}
          >
            <span className="font-mono text-[10px]" style={{ color: "var(--red)" }}>{errMsg}</span>
          </div>
        )}

        {/* CTA button */}
        <button
          onClick={handleTrade}
          disabled={
            status === "confirming" || status === "pending" ||
            (deployed && side === "buy"  && !ethAmt) ||
            (deployed && side === "sell" && !tokAmt)
          }
          className={cn(
            "w-full py-2.5 rounded font-mono font-bold text-sm uppercase tracking-wider transition-all",
            side === "buy" ? "btn-buy" : "btn-sell",
          )}
        >
          {!wallet.isConnected ? "Connect Wallet" :
           !wallet.isCorrectChain ? "Switch to Base" :
           !deployed ? `${token?.symbol || "ASLE"} — Coming Soon` :
           status === "confirming" ? "Confirm in Wallet…" :
           status === "pending"    ? "Confirming…" :
           side === "buy"  ? `Buy ${token?.symbol || ""}` :
           `Sell ${token?.symbol || ""}`}
        </button>

        {/* Engine info */}
        {deployed && engine && (
          <EngineStatsPanel engine={engine} ethUsd={ethUsd} />
        )}
      </div>
    </div>
  )
}

// ── Sub-components ─────────────────────────────────────────────────────────────

function QuoteRow({
  label, value, highlight, warn, dim,
}: {
  label: string; value: string
  highlight?: boolean; warn?: boolean; dim?: boolean
}) {
  return (
    <div className="flex items-center justify-between">
      <span className="font-mono text-[10px]" style={{ color: "var(--text-dim)" }}>{label}</span>
      <span
        className="font-mono text-[10px]"
        style={{
          color: highlight ? "var(--teal)"
               : warn      ? "var(--amber)"
               : dim        ? "var(--text-faint)"
               : "var(--text-secondary)",
        }}
      >
        {value}
      </span>
    </div>
  )
}

function EngineStatsPanel({ engine, ethUsd }: { engine: EngineState; ethUsd: number }) {
  return (
    <div
      className="rounded p-2 flex flex-col gap-1"
      style={{ background: "var(--bg-surface)", border: "1px solid var(--border-dim)" }}
    >
      <span className="font-mono text-[9px] uppercase tracking-wider mb-0.5" style={{ color: "var(--text-dim)" }}>
        Engine State
      </span>
      <QuoteRow label="Pool ETH"   value={`${engine.poolEth.toFixed(4)} ETH`} />
      <QuoteRow label="Floor"      value={`$${fmtPrice(engine.floorPrice * ethUsd)}`} />
      <QuoteRow label="Buyback"    value={`${engine.accBuyback.toFixed(4)} ETH`} />
      <QuoteRow label="Buy fee"    value={`${(engine.fees.effectiveBuy  / 100).toFixed(2)}%`} />
      <QuoteRow label="Sell fee"   value={`${(engine.fees.effectiveSell / 100).toFixed(2)}%`} />
      <QuoteRow
        label="Circuit"
        value={engine.state.circuitBroken ? "BROKEN" : "OK"}
        warn={engine.state.circuitBroken}
      />
    </div>
  )
}
