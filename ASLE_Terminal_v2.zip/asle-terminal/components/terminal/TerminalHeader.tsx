"use client"

import { useState, useEffect, useRef } from "react"
import { cn, fmtPrice, fmtPct, fmtCompact, fmtAddr, copyToClipboard } from "@/lib/utils"
import { PHASE_LABELS, phaseColor } from "@/lib/utils"
import { BASE_EXPLORER } from "@/lib/config"
import type { LaunchedToken, EngineState } from "@/lib/types"
import type { WalletHook } from "@/hooks/use-wallet"
import TokenLogo from "@/components/ui/TokenLogo"

interface TerminalHeaderProps {
  token:    LaunchedToken | null
  engine:   EngineState | null
  ethUsd:   number
  wallet:   WalletHook
  isEngineDeployed: boolean
}

export default function TerminalHeader({
  token, engine, ethUsd, wallet, isEngineDeployed,
}: TerminalHeaderProps) {
  const [copied, setCopied] = useState(false)
  const prevPrice = useRef<number>(0)
  const [priceDir, setPriceDir] = useState<"up" | "down" | null>(null)

  // Track price direction for flash animation
  const displayPrice = engine?.spotPriceUsd ?? (token?.priceUsd || 0)
  useEffect(() => {
    if (prevPrice.current === 0) { prevPrice.current = displayPrice; return }
    if (displayPrice > prevPrice.current) setPriceDir("up")
    else if (displayPrice < prevPrice.current) setPriceDir("down")
    prevPrice.current = displayPrice
    const t = setTimeout(() => setPriceDir(null), 700)
    return () => clearTimeout(t)
  }, [displayPrice])

  const handleCopy = async () => {
    if (!token?.contractAddress) return
    await copyToClipboard(token.contractAddress)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  const priceChange = token?.priceChange24h ?? 0
  const isUp = priceChange >= 0

  return (
    <header
      className="flex items-center h-12 px-3 gap-4 border-b flex-shrink-0"
      style={{ background: "var(--bg-panel)", borderColor: "var(--border-dim)" }}
    >
      {/* ── ASLE Logo ─────────────────────────────────────────── */}
      <div className="flex items-center gap-2 shrink-0">
        <div
          className="flex items-center justify-center w-7 h-7 rounded font-mono font-black text-xs"
          style={{ background: "var(--teal)", color: "var(--bg-base)" }}
        >
          A
        </div>
        <span
          className="font-mono font-bold text-xs tracking-widest uppercase hidden sm:block"
          style={{ color: "var(--text-secondary)" }}
        >
          Terminal
        </span>
      </div>

      <div className="w-px h-6 shrink-0" style={{ background: "var(--border-dim)" }} />

      {/* ── Selected token ────────────────────────────────────── */}
      {token ? (
        <div className="flex items-center gap-2 min-w-0 shrink-0">
          <TokenLogo src={token.logoUrl} symbol={token.symbol} size={22} />
          <div className="flex flex-col leading-none min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="font-mono font-bold text-sm" style={{ color: "var(--text-primary)" }}>
                {token.symbol}
              </span>
              {isEngineDeployed && engine?.state.phase !== undefined && (
                <span
                  className="badge text-[8px]"
                  style={{
                    background: phaseColor(engine.state.phase) + "22",
                    color: phaseColor(engine.state.phase),
                  }}
                >
                  {PHASE_LABELS[engine.state.phase]}
                </span>
              )}
              {token.isNew && (
                <span className="badge badge-amber" style={{ fontSize: "8px" }}>NEW</span>
              )}
            </div>
            <span className="font-mono text-[10px] truncate" style={{ color: "var(--text-dim)" }}>
              {token.name}
            </span>
          </div>
        </div>
      ) : (
        <div className="flex items-center gap-2 shrink-0">
          <div className="w-5 h-5 rounded-full animate-pulse" style={{ background: "var(--bg-hover)" }} />
          <span className="font-mono text-xs" style={{ color: "var(--text-dim)" }}>Select a token</span>
        </div>
      )}

      {/* ── Price ─────────────────────────────────────────────── */}
      {token && (
        <div className="flex items-baseline gap-2 shrink-0">
          <span
            className={cn(
              "font-mono font-bold text-base transition-colors duration-150",
              priceDir === "up"   && "ticker-up",
              priceDir === "down" && "ticker-down",
              !priceDir && "text-primary"
            )}
            style={{ color: !priceDir ? "var(--text-primary)" : undefined }}
          >
            ${fmtPrice(displayPrice)}
          </span>
          <span
            className={cn("font-mono text-xs font-semibold", isUp ? "price-up" : "price-down")}
          >
            {fmtPct(priceChange)}
          </span>
        </div>
      )}

      {/* ── Stats strip ───────────────────────────────────────── */}
      {token && (
        <div className="hidden lg:flex items-center gap-4 text-[11px] font-mono shrink-0">
          <StatItem label="Vol 24h" value={fmtCompact(token.volume24h)} />
          <StatItem label="MCap"    value={fmtCompact(token.marketCap || token.fdv)} />
          <StatItem label="Liq"     value={fmtCompact(token.liquidity)} />
          {isEngineDeployed && engine && (
            <>
              <StatItem label="TWAP"    value={`$${fmtPrice(engine.twapFast * ethUsd)}`} />
              <StatItem label="Fee Buy" value={`${(engine.fees.effectiveBuy / 100).toFixed(2)}%`} />
            </>
          )}
        </div>
      )}

      {/* ── Contract address ──────────────────────────────────── */}
      {token?.contractAddress && token.contractAddress !== "0x0000000000000000000000000000000000000000" && (
        <div className="hidden xl:flex items-center gap-1.5 shrink-0">
          <span className="font-mono text-[10px]" style={{ color: "var(--text-dim)" }}>
            {fmtAddr(token.contractAddress, 6)}
          </span>
          <button
            onClick={handleCopy}
            className="flex items-center justify-center w-5 h-5 rounded transition-colors"
            style={{
              background: copied ? "var(--teal-dim)" : "transparent",
              color: copied ? "var(--teal)" : "var(--text-dim)",
            }}
            title="Copy contract address"
          >
            {copied ? (
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <polyline points="20 6 9 17 4 12" />
              </svg>
            ) : (
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="9" y="9" width="13" height="13" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
              </svg>
            )}
          </button>
          <a
            href={`${BASE_EXPLORER}/address/${token.contractAddress}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center w-5 h-5 rounded transition-colors"
            style={{ color: "var(--text-dim)" }}
            title="View on Basescan"
          >
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
              <polyline points="15 3 21 3 21 9" /><line x1="10" y1="14" x2="21" y2="3" />
            </svg>
          </a>
        </div>
      )}

      {/* ── Spacer ────────────────────────────────────────────── */}
      <div className="flex-1" />

      {/* ── Engine status ─────────────────────────────────────── */}
      <div className="flex items-center gap-2 shrink-0">
        <div className="flex items-center gap-1.5">
          <div className={cn("status-dot", isEngineDeployed ? "online" : "pending")} />
          <span className="font-mono text-[10px] hidden md:block" style={{ color: "var(--text-dim)" }}>
            {isEngineDeployed ? "Engine Live" : "Pre-Launch"}
          </span>
        </div>
      </div>

      <div className="w-px h-6 shrink-0" style={{ background: "var(--border-dim)" }} />

      {/* ── Wallet button ─────────────────────────────────────── */}
      <WalletButton wallet={wallet} />
    </header>
  )
}

// ── Sub-components ────────────────────────────────────────────────────────────

function StatItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center gap-1">
      <span style={{ color: "var(--text-dim)" }}>{label}</span>
      <span style={{ color: "var(--text-secondary)" }}>{value}</span>
    </div>
  )
}

function WalletButton({ wallet }: { wallet: WalletHook }) {
  const [open, setOpen] = useState(false)

  if (!wallet.isConnected) {
    return (
      <button
        onClick={wallet.connect}
        disabled={wallet.isConnecting}
        className="flex items-center gap-1.5 px-3 h-7 rounded font-mono font-semibold text-xs transition-all"
        style={{
          background: "var(--teal)",
          color: "var(--bg-base)",
          opacity: wallet.isConnecting ? 0.7 : 1,
        }}
      >
        {wallet.isConnecting ? (
          <>
            <span className="w-3 h-3 rounded-full border-[1.5px] border-current border-t-transparent animate-spin" />
            Connecting
          </>
        ) : (
          <>
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="2" y="7" width="20" height="14" rx="2" />
              <path d="M16 3H8a2 2 0 0 0-2 2v2h12V5a2 2 0 0 0-2-2z" />
              <circle cx="16" cy="14" r="1" fill="currentColor" />
            </svg>
            Connect
          </>
        )}
      </button>
    )
  }

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(p => !p)}
        className="flex items-center gap-1.5 px-2.5 h-7 rounded font-mono text-xs transition-all"
        style={{
          background: "var(--bg-hover)",
          border: "1px solid var(--border-std)",
          color: "var(--text-primary)",
        }}
      >
        {!wallet.isCorrectChain && (
          <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: "var(--amber)" }} />
        )}
        <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: "var(--teal)" }} />
        {wallet.shortAddress}
        <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <polyline points={open ? "18 15 12 9 6 15" : "6 9 12 15 18 9"} />
        </svg>
      </button>

      {open && (
        <div
          className="absolute right-0 top-9 z-50 rounded min-w-[180px] py-1 shadow-xl"
          style={{
            background: "var(--bg-surface)",
            border: "1px solid var(--border-std)",
          }}
        >
          {!wallet.isCorrectChain && (
            <button
              onClick={() => { wallet.switchChain(); setOpen(false) }}
              className="w-full flex items-center gap-2 px-3 py-2 text-left font-mono text-xs transition-colors hover:bg-[var(--bg-hover)]"
              style={{ color: "var(--amber)" }}
            >
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
                <line x1="12" y1="9" x2="12" y2="13" /><line x1="12" y1="17" x2="12.01" y2="17" />
              </svg>
              Switch to Base
            </button>
          )}
          <div
            className="flex items-center gap-2 px-3 py-2"
            style={{ color: "var(--text-dim)", borderBottom: "1px solid var(--border-dim)" }}
          >
            <span className="font-mono text-[10px]">{wallet.address ? fmtAddr(wallet.address, 6) : ""}</span>
          </div>
          <button
            onClick={() => { wallet.disconnect(); setOpen(false) }}
            className="w-full flex items-center gap-2 px-3 py-2 text-left font-mono text-xs transition-colors hover:bg-[var(--bg-hover)]"
            style={{ color: "var(--text-secondary)" }}
          >
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
              <polyline points="16 17 21 12 16 7" /><line x1="21" y1="12" x2="9" y2="12" />
            </svg>
            Disconnect
          </button>
        </div>
      )}

      {open && (
        <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
      )}
    </div>
  )
}
