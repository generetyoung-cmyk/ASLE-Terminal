"use client"

import { useState } from "react"
import { cn, fmtCompact, fmtPct, fmtTokens, fmtTimeAgo, copyToClipboard, fmtAddr, fmtPrice } from "@/lib/utils"
import { PHASE_LABELS, phaseColor, GRADUATION_TARGET_ETH } from "@/lib/utils"
import { BASE_EXPLORER } from "@/lib/config"
import type { LaunchedToken, EngineState, PriceDecomposition } from "@/lib/types"
import TokenLogo from "@/components/ui/TokenLogo"

interface TokenInfoProps {
  token:   LaunchedToken | null
  engine:  EngineState   | null
  decomp:  PriceDecomposition | null
  ethUsd:  number
  isEngineDeployed: boolean
  curveProgress: number
}

type Tab = "info" | "curve" | "engine"

export default function TokenInfoPanel({
  token, engine, decomp, ethUsd, isEngineDeployed, curveProgress,
}: TokenInfoProps) {
  const [tab, setTab] = useState<Tab>("info")
  const [copied, setCopied] = useState(false)

  if (!token) {
    return (
      <div className="flex flex-col h-full items-center justify-center gap-3" style={{ background: "var(--bg-panel)" }}>
        <div
          className="w-10 h-10 rounded-full flex items-center justify-center"
          style={{ background: "var(--bg-surface)", border: "1px solid var(--border-dim)" }}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--text-faint)" strokeWidth="1.5">
            <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
        </div>
        <span className="font-mono text-xs" style={{ color: "var(--text-dim)" }}>Select a token</span>
      </div>
    )
  }

  const handleCopy = async () => {
    if (!token.contractAddress) return
    await copyToClipboard(token.contractAddress)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  const TABS: { key: Tab; label: string }[] = [
    { key: "info",   label: "Info"   },
    { key: "curve",  label: "Curve"  },
    ...(isEngineDeployed && token.isASLE ? [{ key: "engine" as Tab, label: "Engine" }] : []),
  ]

  return (
    <div className="flex flex-col h-full" style={{ background: "var(--bg-panel)" }}>
      {/* Token hero */}
      <div
        className="flex items-start gap-2.5 px-3 py-2.5 border-b shrink-0"
        style={{ borderColor: "var(--border-dim)" }}
      >
        <TokenLogo src={token.logoUrl} symbol={token.symbol} size={36} />
        <div className="flex flex-col gap-0.5 min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <span className="font-mono font-bold text-sm" style={{ color: "var(--text-primary)" }}>
              {token.symbol}
            </span>
            {token.communityId && (
              <span className="badge badge-teal" style={{ fontSize: "7px" }}>dApp</span>
            )}
            {token.isNew && (
              <span className="badge badge-amber" style={{ fontSize: "7px" }}>NEW</span>
            )}
            {token.isTrending && (
              <span className="badge badge-blue" style={{ fontSize: "7px" }}>🔥</span>
            )}
          </div>
          <span className="font-mono text-[10px] truncate" style={{ color: "var(--text-secondary)" }}>
            {token.name}
          </span>
          {token.contractAddress && token.contractAddress !== "0x0000000000000000000000000000000000000000" && (
            <div className="flex items-center gap-1 mt-0.5">
              <span className="font-mono text-[9px]" style={{ color: "var(--text-dim)" }}>
                {fmtAddr(token.contractAddress, 5)}
              </span>
              <button onClick={handleCopy} style={{ color: copied ? "var(--teal)" : "var(--text-dim)" }}>
                <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  {copied
                    ? <polyline points="20 6 9 17 4 12" />
                    : <><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></>
                  }
                </svg>
              </button>
              <a
                href={`${BASE_EXPLORER}/address/${token.contractAddress}`}
                target="_blank" rel="noopener noreferrer"
                style={{ color: "var(--text-dim)" }}
              >
                <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
                  <polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
                </svg>
              </a>
            </div>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="tab-bar shrink-0">
        {TABS.map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={cn("tab-item", tab === t.key && "active")}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div className="flex-1 overflow-y-auto px-3 py-2">
        {tab === "info"   && <InfoTab   token={token} ethUsd={ethUsd} />}
        {tab === "curve"  && <CurveTab  token={token} engine={engine} ethUsd={ethUsd} curveProgress={curveProgress} isEngineDeployed={isEngineDeployed} />}
        {tab === "engine" && decomp && <EngineTab decomp={decomp} engine={engine} ethUsd={ethUsd} />}
      </div>
    </div>
  )
}

// ── Info tab ──────────────────────────────────────────────────────────────────
function InfoTab({ token, ethUsd }: { token: LaunchedToken; ethUsd: number }) {
  const stats: [string, string][] = [
    ["Price USD",    `$${fmtPrice(token.priceUsd)}`],
    ["Price ETH",    `${fmtPrice(token.priceEth)} ETH`],
    ["1h Change",    fmtPct(token.priceChangeH1)],
    ["6h Change",    fmtPct(token.priceChangeH6)],
    ["24h Change",   fmtPct(token.priceChange24h)],
    ["Vol 24h",      fmtCompact(token.volume24h)],
    ["Market Cap",   fmtCompact(token.marketCap || token.fdv)],
    ["FDV",          fmtCompact(token.fdv)],
    ["Liquidity",    fmtCompact(token.liquidity)],
    ["Members",      token.memberCount > 0 ? token.memberCount.toLocaleString() : "—"],
    ["Created",      token.createdAt > 0 ? fmtTimeAgo(token.createdAt) : "—"],
  ]

  return (
    <div className="flex flex-col gap-0.5">
      {token.description && (
        <p
          className="font-mono text-[10px] leading-relaxed mb-2 pb-2 border-b"
          style={{ color: "var(--text-secondary)", borderColor: "var(--border-dim)" }}
        >
          {token.description.slice(0, 160)}
          {token.description.length > 160 ? "…" : ""}
        </p>
      )}
      {stats.map(([label, value]) => (
        <StatRow key={label} label={label} value={value}
          valueColor={
            label.includes("Change")
              ? parseFloat(value) >= 0 ? "var(--teal)" : "var(--red)"
              : undefined
          }
        />
      ))}
    </div>
  )
}

// ── Curve tab ─────────────────────────────────────────────────────────────────
function CurveTab({
  token, engine, ethUsd, curveProgress, isEngineDeployed,
}: {
  token: LaunchedToken; engine: EngineState | null; ethUsd: number
  curveProgress: number; isEngineDeployed: boolean
}) {
  const poolEth = engine?.poolEth || token.poolEth
  const poolTok = engine?.poolTok || token.poolTok
  const phase   = engine?.state.phase ?? token.phase

  return (
    <div className="flex flex-col gap-3">
      {/* Graduation progress */}
      <div
        className="rounded p-2.5"
        style={{ background: "var(--bg-surface)", border: "1px solid var(--border-dim)" }}
      >
        <div className="flex items-center justify-between mb-2">
          <span className="font-mono text-[10px]" style={{ color: "var(--text-dim)" }}>
            Bonding Curve Progress
          </span>
          <span className="font-mono text-[11px] font-bold" style={{ color: "var(--gold)" }}>
            {curveProgress.toFixed(1)}%
          </span>
        </div>
        <div className="curve-bar">
          <div className="curve-bar-fill" style={{ width: `${curveProgress}%` }} />
        </div>
        <div className="flex items-center justify-between mt-1.5">
          <span className="font-mono text-[9px]" style={{ color: "var(--text-dim)" }}>
            {poolEth > 0 ? `${poolEth.toFixed(3)} ETH raised` : "Not started"}
          </span>
          <span className="font-mono text-[9px]" style={{ color: "var(--text-dim)" }}>
            Target: {GRADUATION_TARGET_ETH} ETH
          </span>
        </div>
      </div>

      {/* Phase */}
      {isEngineDeployed && (
        <div className="flex items-center justify-between">
          <span className="stat-label">Current Phase</span>
          <span
            className="badge"
            style={{
              background: phaseColor(phase) + "22",
              color: phaseColor(phase),
            }}
          >
            {PHASE_LABELS[phase]}
          </span>
        </div>
      )}

      {/* Pool state */}
      {(poolEth > 0 || poolTok > 0) && (
        <>
          <StatRow label="Pool ETH"   value={`${poolEth.toFixed(4)} ETH`} />
          <StatRow label="Pool Tokens" value={fmtTokens(poolTok)} />
          <StatRow label="Pool Value"  value={fmtCompact(poolEth * ethUsd)} />
        </>
      )}

      {!isEngineDeployed && (
        <div
          className="rounded p-2 mt-1"
          style={{ background: "var(--amber-dim)", border: "1px solid rgba(245,158,11,0.15)" }}
        >
          <p className="font-mono text-[10px] text-center" style={{ color: "var(--amber)" }}>
            Curve data available after ASLE Engine launch
          </p>
        </div>
      )}
    </div>
  )
}

// ── Engine tab ────────────────────────────────────────────────────────────────
function EngineTab({
  decomp, engine, ethUsd,
}: {
  decomp: PriceDecomposition; engine: EngineState | null; ethUsd: number
}) {
  return (
    <div className="flex flex-col gap-0.5">
      <span className="panel-label mb-1">Price Decomposition</span>
      <StatRow label="P₀ (Base)"  value={`${fmtPrice(decomp.P0  * ethUsd)} USD`} />
      <StatRow label="T₁ (Supply)" value={decomp.T1.toFixed(6)} />
      <StatRow label="T₂ (Buy EMA)" value={decomp.T2.toFixed(6)} />
      <StatRow label="T₃ (Sell EMA)" value={decomp.T3.toFixed(6)} />
      <StatRow label="Composed"    value={`$${fmtPrice(decomp.composed * ethUsd)}`} highlight />

      <div className="border-t mt-1 pt-1" style={{ borderColor: "var(--border-dim)" }}>
        <span className="panel-label mb-1 block">Adaptive Params</span>
        <StatRow label="Alpha" value={decomp.params.alpha.toFixed(6)} />
        <StatRow label="Beta"  value={decomp.params.beta.toFixed(6)}  />
        <StatRow label="Gamma" value={decomp.params.gamma.toFixed(6)} />
      </div>

      <div className="border-t mt-1 pt-1" style={{ borderColor: "var(--border-dim)" }}>
        <span className="panel-label mb-1 block">EMA / GARCH</span>
        <StatRow label="EMA-V (volume)" value={decomp.ema.V.toFixed(6)} />
        <StatRow label="EMA-D (dir)"    value={decomp.ema.D.toFixed(6)} />
        <StatRow label="σ (adaptive)"   value={decomp.ema.sigma.toFixed(6)} />
      </div>

      {engine && (
        <div className="border-t mt-1 pt-1" style={{ borderColor: "var(--border-dim)" }}>
          <span className="panel-label mb-1 block">Circuit State</span>
          <StatRow label="Broken"  value={engine.state.circuitBroken ? "YES" : "No"} valueColor={engine.state.circuitBroken ? "var(--red)" : "var(--teal)"} />
          <StatRow label="Trading" value={engine.state.trading ? "Active" : "Paused"} valueColor={engine.state.trading ? "var(--teal)" : "var(--amber)"} />
          <StatRow label="LP Lock" value={engine.state.lpLocked ? "Locked" : "Unlocked"} />
        </div>
      )}
    </div>
  )
}

// ── Shared atoms ──────────────────────────────────────────────────────────────
function StatRow({
  label, value, valueColor, highlight,
}: {
  label: string; value: string; valueColor?: string; highlight?: boolean
}) {
  return (
    <div className="stat-row">
      <span className="stat-label">{label}</span>
      <span
        className="stat-value tabular-nums"
        style={{ color: valueColor || (highlight ? "var(--teal)" : undefined) }}
      >
        {value}
      </span>
    </div>
  )
}
