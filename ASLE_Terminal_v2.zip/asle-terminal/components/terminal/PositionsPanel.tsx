"use client"

import { useState, useEffect } from "react"
import { cn, fmtCompact, fmtPrice, fmtTokens, fmtPct } from "@/lib/utils"
import type { WalletHook } from "@/hooks/use-wallet"
import type { ASLEEngineHook } from "@/hooks/use-asle-engine"
import type { WalletInfo } from "@/lib/types"

interface PositionsPanelProps {
  wallet:      WalletHook
  engineHook:  ASLEEngineHook
  ethUsd:      number
}

type Tab = "portfolio" | "history"

export default function PositionsPanel({ wallet, engineHook, ethUsd }: PositionsPanelProps) {
  const [tab,  setTab]  = useState<Tab>("portfolio")
  const [info, setInfo] = useState<WalletInfo | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!wallet.isConnected || !wallet.address || !engineHook.isDeployed) return
    setLoading(true)
    engineHook.getWalletInfo(wallet.address).then(w => {
      setInfo(w)
      setLoading(false)
    }).catch(() => setLoading(false))
  }, [wallet.isConnected, wallet.address, engineHook, engineHook.engine?.lastUpdate])

  return (
    <div className="flex flex-col h-full" style={{ background: "var(--bg-panel)" }}>
      {/* Tab bar */}
      <div className="tab-bar shrink-0">
        {(["portfolio", "history"] as const).map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={cn("tab-item capitalize", tab === t && "active")}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto">
        {!wallet.isConnected ? (
          <EmptyState msg="Connect wallet to view portfolio" />
        ) : tab === "portfolio" ? (
          <PortfolioTab
            wallet={wallet}
            info={info}
            loading={loading}
            ethUsd={ethUsd}
            isEngineDeployed={engineHook.isDeployed}
          />
        ) : (
          <HistoryTab wallet={wallet} />
        )}
      </div>
    </div>
  )
}

// ── Portfolio tab ─────────────────────────────────────────────────────────────
function PortfolioTab({
  wallet, info, loading, ethUsd, isEngineDeployed,
}: {
  wallet: WalletHook; info: WalletInfo | null; loading: boolean
  ethUsd: number; isEngineDeployed: boolean
}) {
  const ethBalance = wallet.isConnected ? 0 : 0 // ETH from wallet is in walletInfo

  if (loading) {
    return (
      <div className="flex items-center justify-center h-16 gap-2">
        <div className="w-3.5 h-3.5 rounded-full border-[1.5px] border-t-transparent border-[var(--teal)] animate-spin" />
        <span className="font-mono text-[10px]" style={{ color: "var(--text-dim)" }}>Loading…</span>
      </div>
    )
  }

  return (
    <div className="px-3 py-2 flex flex-col gap-3">
      {/* ETH balance always shown */}
      {info && (
        <div
          className="rounded p-2"
          style={{ background: "var(--bg-surface)", border: "1px solid var(--border-dim)" }}
        >
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-1.5">
              <div
                className="w-5 h-5 rounded-full flex items-center justify-center font-mono font-bold text-[9px]"
                style={{ background: "var(--blue-dim)", color: "var(--blue)" }}
              >
                Ξ
              </div>
              <span className="font-mono text-xs font-bold" style={{ color: "var(--text-primary)" }}>ETH</span>
            </div>
            <span className="font-mono text-xs font-bold" style={{ color: "var(--text-primary)" }}>
              {info.balanceEthFmt}
            </span>
          </div>
          <div className="flex justify-end">
            <span className="font-mono text-[10px]" style={{ color: "var(--text-dim)" }}>
              {fmtCompact(parseFloat(info.balanceEthFmt) * ethUsd)}
            </span>
          </div>
        </div>
      )}

      {/* ASLE balance — only when engine deployed */}
      {isEngineDeployed && info && (
        <div
          className="rounded p-2"
          style={{ background: "var(--bg-surface)", border: "1px solid var(--border-dim)" }}
        >
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-1.5">
              <div
                className="w-5 h-5 rounded-full flex items-center justify-center font-mono font-bold text-[9px]"
                style={{ background: "var(--teal-dim)", color: "var(--teal)" }}
              >
                A
              </div>
              <span className="font-mono text-xs font-bold" style={{ color: "var(--text-primary)" }}>ASLE</span>
              {info.tier !== undefined && (
                <span
                  className="badge"
                  style={{
                    background: ["var(--bg-hover)","var(--bg-hover)","var(--gold-dim)","rgba(139,92,246,0.15)"][info.tier],
                    color: ["var(--text-dim)","var(--text-secondary)","var(--gold)","var(--purple)"][info.tier],
                    fontSize: "7px",
                  }}
                >
                  {info.tierLabel}
                </span>
              )}
            </div>
            <span className="font-mono text-xs font-bold" style={{ color: "var(--teal)" }}>
              {info.balanceAsleFmt}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="font-mono text-[9px]" style={{ color: "var(--text-dim)" }}>
              {info.pctOfSupply} of supply
            </span>
            <span className="font-mono text-[10px]" style={{ color: "var(--text-dim)" }}>
              {fmtCompact(info.valueUsd)}
            </span>
          </div>

          {/* Fee / limit info */}
          <div
            className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t"
            style={{ borderColor: "var(--border-dim)" }}
          >
            <MiniStat label="Sell fee est." value={info.sellFeePct} />
            <MiniStat label="Fee exempt"    value={info.feeExempt ? "Yes" : "No"} />
          </div>
        </div>
      )}

      {!isEngineDeployed && (
        <div
          className="rounded p-2 text-center"
          style={{ background: "var(--amber-dim)", border: "1px solid rgba(245,158,11,0.15)" }}
        >
          <p className="font-mono text-[10px]" style={{ color: "var(--amber)" }}>
            ASLE balance visible after engine launch
          </p>
        </div>
      )}

      {!info && isEngineDeployed && (
        <EmptyState msg="Could not load wallet data" />
      )}
    </div>
  )
}

// ── History tab ───────────────────────────────────────────────────────────────
function HistoryTab({ wallet: _ }: { wallet: WalletHook }) {
  // On-chain trade history requires an indexer / event log.
  // For now, show a "coming soon" state that explains what will appear here.
  return (
    <div className="flex flex-col items-center justify-center h-32 gap-2 px-4 text-center">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--text-faint)" strokeWidth="1.5">
        <circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" />
      </svg>
      <span className="font-mono text-[10px]" style={{ color: "var(--text-dim)" }}>
        Trade history available after engine launch.<br />
        Indexed from on-chain Buy/Sell events.
      </span>
    </div>
  )
}

// ── Atoms ─────────────────────────────────────────────────────────────────────
function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col">
      <span className="font-mono text-[9px]" style={{ color: "var(--text-faint)" }}>{label}</span>
      <span className="font-mono text-[10px]" style={{ color: "var(--text-secondary)" }}>{value}</span>
    </div>
  )
}

function EmptyState({ msg }: { msg: string }) {
  return (
    <div className="flex items-center justify-center h-24">
      <span className="font-mono text-[10px] text-center" style={{ color: "var(--text-dim)" }}>{msg}</span>
    </div>
  )
}
