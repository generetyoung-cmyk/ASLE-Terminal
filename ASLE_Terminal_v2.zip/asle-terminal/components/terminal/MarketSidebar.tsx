"use client"

import { useState } from "react"
import { cn, fmtCompact, fmtPct, fmtPrice, fmtTimeAgo } from "@/lib/utils"
import type { TokenListHook } from "@/hooks/use-token-list"
import type { TokenFilter, TokenSortKey } from "@/lib/types"
import TokenLogo from "@/components/ui/TokenLogo"

interface MarketSidebarProps {
  hook: TokenListHook
}

const FILTERS: { key: TokenFilter; label: string }[] = [
  { key: "all",        label: "All"       },
  { key: "new",        label: "New"       },
  { key: "trending",   label: "Trending"  },
  { key: "graduating", label: "🎓 Grad"   },
]

const SORTS: { key: TokenSortKey; label: string }[] = [
  { key: "volume",        label: "Vol"   },
  { key: "marketCap",     label: "MCap"  },
  { key: "priceChange",   label: "Chg"   },
  { key: "liquidity",     label: "Liq"   },
  { key: "curveProgress", label: "Curve" },
  { key: "age",           label: "New"   },
]

export default function MarketSidebar({ hook }: MarketSidebarProps) {
  const { tokens, isLoading, filter, sortKey, search,
    setFilter, setSortKey, setSearch,
    selectedToken, setSelectedToken } = hook

  return (
    <div className="flex flex-col h-full" style={{ background: "var(--bg-panel)" }}>

      {/* ── Search ───────────────────────────────────────────── */}
      <div className="px-2 pt-2 pb-1.5 shrink-0 border-b" style={{ borderColor: "var(--border-dim)" }}>
        <div className="relative">
          <svg
            className="absolute left-2.5 top-1/2 -translate-y-1/2"
            width="11" height="11" viewBox="0 0 24 24"
            fill="none" stroke="var(--text-dim)" strokeWidth="2.5"
          >
            <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search tokens…"
            className="terminal-input pl-7 text-[11px] h-7"
            style={{ fontSize: "11px", height: "28px", padding: "0 8px 0 26px" }}
          />
        </div>
      </div>

      {/* ── Filter tabs ──────────────────────────────────────── */}
      <div
        className="flex items-center px-1 shrink-0 border-b"
        style={{ borderColor: "var(--border-dim)" }}
      >
        {FILTERS.map(f => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={cn(
              "px-2 py-1.5 font-mono text-[10px] transition-colors whitespace-nowrap border-b-2 -mb-px",
              filter === f.key
                ? "border-b-[var(--teal)] text-[var(--teal)]"
                : "border-b-transparent text-[var(--text-dim)] hover:text-[var(--text-secondary)]"
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* ── Sort row ─────────────────────────────────────────── */}
      <div
        className="flex items-center justify-between px-2 py-1 shrink-0 border-b"
        style={{ borderColor: "var(--border-dim)" }}
      >
        <span className="font-mono text-[9px] uppercase tracking-wider" style={{ color: "var(--text-dim)" }}>
          {tokens.length} tokens
        </span>
        <div className="flex items-center gap-0.5">
          {SORTS.map(s => (
            <button
              key={s.key}
              onClick={() => setSortKey(s.key)}
              className={cn(
                "px-1.5 py-0.5 rounded font-mono text-[9px] transition-colors",
                sortKey === s.key
                  ? "bg-[var(--teal-dim)] text-[var(--teal)]"
                  : "text-[var(--text-dim)] hover:text-[var(--text-secondary)]"
              )}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── Token list ───────────────────────────────────────── */}
      <div className="flex-1 overflow-y-auto">
        {isLoading && tokens.length === 0 ? (
          <SkeletonList />
        ) : tokens.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-32 gap-2">
            <span className="font-mono text-xs" style={{ color: "var(--text-dim)" }}>No tokens found</span>
          </div>
        ) : (
          tokens.map(token => (
            <button
              key={token.contractAddress || token.name}
              onClick={() => setSelectedToken(token)}
              className={cn(
                "w-full flex flex-col px-2 py-2 transition-colors border-b text-left",
                selectedToken?.contractAddress === token.contractAddress
                  ? "bg-[var(--bg-active)]"
                  : "hover:bg-[var(--bg-hover)]"
              )}
              style={{ borderColor: "var(--border-dim)" }}
            >
              <TokenRow token={token} isSelected={selectedToken?.contractAddress === token.contractAddress} sortKey={sortKey} />
            </button>
          ))
        )}
      </div>
    </div>
  )
}

// ── Token row ─────────────────────────────────────────────────────────────────
function TokenRow({ token, isSelected, sortKey }: {
  token: Parameters<typeof import("@/hooks/use-token-list").useTokenList>[0] extends undefined ? import("@/lib/types").LaunchedToken : import("@/lib/types").LaunchedToken
  isSelected: boolean
  sortKey: TokenSortKey
}) {
  const isUp = token.priceChange24h >= 0

  return (
    <>
      {/* Row 1: logo + name + price */}
      <div className="flex items-center gap-2 w-full">
        <div className="relative shrink-0">
          <TokenLogo src={token.logoUrl} symbol={token.symbol} size={26} />
          {token.communityId && (
            <div
              className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full flex items-center justify-center"
              style={{ background: "var(--teal)", border: "1px solid var(--bg-panel)" }}
              title="ASLE dApp token"
            >
              <svg width="5" height="5" viewBox="0 0 24 24" fill="var(--bg-base)">
                <polyline points="20 6 9 17 4 12" strokeWidth="3" stroke="var(--bg-base)" fill="none" strokeLinecap="round" />
              </svg>
            </div>
          )}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1 min-w-0">
              <span
                className="font-mono font-bold text-[12px] truncate"
                style={{ color: isSelected ? "var(--teal)" : "var(--text-primary)" }}
              >
                {token.symbol}
              </span>
              {token.isNew && (
                <span className="badge badge-amber" style={{ fontSize: "7px", padding: "0 3px" }}>NEW</span>
              )}
              {token.isGraduating && (
                <span className="badge badge-gold" style={{ fontSize: "7px", padding: "0 3px" }}>🎓</span>
              )}
            </div>
            <span className="font-mono text-[11px] tabular-nums shrink-0" style={{ color: "var(--text-primary)" }}>
              ${fmtPrice(token.priceUsd)}
            </span>
          </div>

          <div className="flex items-center justify-between mt-0.5">
            <span
              className="font-mono text-[9px] truncate max-w-[70px]"
              style={{ color: "var(--text-dim)" }}
            >
              {token.name}
            </span>
            <span
              className={cn("font-mono text-[10px] font-semibold tabular-nums shrink-0", isUp ? "price-up" : "price-down")}
            >
              {fmtPct(token.priceChange24h)}
            </span>
          </div>
        </div>
      </div>

      {/* Row 2: secondary stat based on sort */}
      <div className="flex items-center justify-between mt-1 pl-9">
        <SecondaryStats token={token} sortKey={sortKey} />
      </div>
    </>
  )
}

function SecondaryStats({
  token,
  sortKey,
}: {
  token: import("@/lib/types").LaunchedToken
  sortKey: TokenSortKey
}) {
  return (
    <div className="flex items-center gap-3 w-full">
      {sortKey === "volume" || sortKey === "age" ? (
        <>
          <Stat label="Vol" value={fmtCompact(token.volume24h)} />
          <Stat label="Liq" value={fmtCompact(token.liquidity)} />
        </>
      ) : sortKey === "marketCap" ? (
        <>
          <Stat label="MCap" value={fmtCompact(token.marketCap || token.fdv)} />
          <Stat label="Vol"  value={fmtCompact(token.volume24h)} />
        </>
      ) : sortKey === "liquidity" ? (
        <>
          <Stat label="Liq"  value={fmtCompact(token.liquidity)} />
          <Stat label="Vol"  value={fmtCompact(token.volume24h)} />
        </>
      ) : sortKey === "curveProgress" ? (
        <div className="flex-1 flex items-center gap-2">
          <div className="flex-1 curve-bar">
            <div
              className="curve-bar-fill"
              style={{ width: `${token.curveProgress}%` }}
            />
          </div>
          <span className="font-mono text-[9px] shrink-0" style={{ color: "var(--text-dim)" }}>
            {token.curveProgress.toFixed(1)}%
          </span>
        </div>
      ) : (
        <>
          <Stat label="Vol" value={fmtCompact(token.volume24h)} />
          <Stat label="Liq" value={fmtCompact(token.liquidity)} />
        </>
      )}

      {token.createdAt > 0 && (
        <span
          className="font-mono text-[9px] ml-auto shrink-0"
          style={{ color: "var(--text-faint)" }}
        >
          {fmtTimeAgo(token.createdAt)}
        </span>
      )}
    </div>
  )
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center gap-1">
      <span className="font-mono text-[9px]" style={{ color: "var(--text-faint)" }}>{label}</span>
      <span className="font-mono text-[9px]" style={{ color: "var(--text-dim)" }}>{value}</span>
    </div>
  )
}

function SkeletonList() {
  return (
    <>
      {Array.from({ length: 12 }).map((_, i) => (
        <div
          key={i}
          className="flex items-center gap-2 px-2 py-2 border-b"
          style={{ borderColor: "var(--border-dim)" }}
        >
          <div className="w-7 h-7 rounded-full animate-pulse shrink-0" style={{ background: "var(--bg-hover)" }} />
          <div className="flex-1">
            <div className="flex justify-between mb-1">
              <div className="w-12 h-2.5 rounded animate-pulse" style={{ background: "var(--bg-hover)" }} />
              <div className="w-14 h-2.5 rounded animate-pulse" style={{ background: "var(--bg-hover)" }} />
            </div>
            <div className="flex justify-between">
              <div className="w-16 h-2 rounded animate-pulse" style={{ background: "var(--bg-surface)" }} />
              <div className="w-10 h-2 rounded animate-pulse" style={{ background: "var(--bg-surface)" }} />
            </div>
          </div>
        </div>
      ))}
    </>
  )
}
