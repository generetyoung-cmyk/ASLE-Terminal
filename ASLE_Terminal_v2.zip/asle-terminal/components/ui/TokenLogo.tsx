"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"

interface TokenLogoProps {
  src?:       string
  symbol:     string
  size?:      number
  className?: string
}

// Very limited set of IPFS gateways — try them in order
function resolveUrl(src?: string): string {
  if (!src) return ""
  if (src.startsWith("data:"))   return src
  if (src.startsWith("http"))    return src
  if (src.startsWith("ipfs://")) {
    return "https://cloudflare-ipfs.com/ipfs/" + src.slice(7)
  }
  return src
}

export default function TokenLogo({ src, symbol, size = 28, className }: TokenLogoProps) {
  const [failed, setFailed] = useState(false)
  const url = resolveUrl(src)

  if (!url || failed) {
    return <Fallback symbol={symbol} size={size} className={className} />
  }

  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={url}
      alt={symbol}
      width={size}
      height={size}
      className={cn("token-logo shrink-0", className)}
      style={{ width: size, height: size }}
      onError={() => setFailed(true)}
    />
  )
}

function Fallback({
  symbol, size, className,
}: {
  symbol: string; size: number; className?: string
}) {
  const letters = symbol.slice(0, 2).toUpperCase()
  const fontSize = Math.max(7, Math.floor(size * 0.38))

  // Deterministic color from symbol
  let hash = 0
  for (let i = 0; i < symbol.length; i++) hash = symbol.charCodeAt(i) + ((hash << 5) - hash)
  const hue = Math.abs(hash) % 360
  const bg  = `hsl(${hue}, 40%, 20%)`
  const fg  = `hsl(${hue}, 70%, 70%)`

  return (
    <div
      className={cn("token-logo-fallback shrink-0", className)}
      style={{ width: size, height: size, background: bg, fontSize, color: fg }}
    >
      {letters}
    </div>
  )
}
