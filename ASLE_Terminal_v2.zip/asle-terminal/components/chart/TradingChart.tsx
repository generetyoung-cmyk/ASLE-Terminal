"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { cn } from "@/lib/utils"
import type { CandleData } from "@/lib/types"
import type { ChartTimeframe } from "@/hooks/use-selected-token"

interface TradingChartProps {
  candles:   CandleData[]
  isLoading: boolean
  timeframe: ChartTimeframe
  onTimeframeChange: (tf: ChartTimeframe) => void
  twapPrice?: number   // overlay from ASLE engine
  emaPrice?:  number   // overlay
  symbol:     string
}

const TIMEFRAMES: ChartTimeframe[] = ["1m", "5m", "15m", "1h", "4h", "1d"]

// ── Color constants ────────────────────────────────────────────────────────────
const C = {
  bg:         "#05070C",
  grid:       "#151D28",
  gridLabel:  "#2D3748",
  bull:       "#00D4AA",
  bullFill:   "rgba(0,212,170,0.15)",
  bear:       "#F6465D",
  bearFill:   "rgba(246,70,93,0.15)",
  wick:       "#4A5568",
  twap:       "#F59E0B",
  ema:        "#8B5CF6",
  volume:     "rgba(255,255,255,0.06)",
  crosshair:  "#2A3A50",
  label:      "#8B949E",
  tooltip:    "#0D1018",
}

const PADDING = { top: 20, right: 64, bottom: 40, left: 8 }

export default function TradingChart({
  candles, isLoading, timeframe, onTimeframeChange, twapPrice, emaPrice, symbol,
}: TradingChartProps) {
  const canvasRef  = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [cursor, setCursor] = useState<{ x: number; y: number; candle?: CandleData } | null>(null)
  const [chartType, setChartType] = useState<"candle" | "line">("candle")
  const dprRef = useRef(1)

  // ── Draw ──────────────────────────────────────────────────────────────────
  const draw = useCallback(() => {
    const canvas = canvasRef.current
    const ctx    = canvas?.getContext("2d")
    if (!canvas || !ctx || candles.length < 2) return

    const dpr = dprRef.current
    const W   = canvas.width  / dpr
    const H   = canvas.height / dpr

    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.scale(dpr, dpr)

    const plotW = W - PADDING.left - PADDING.right
    const plotH = H - PADDING.top  - PADDING.bottom

    // Data range
    const visible = candles.slice(-Math.max(60, Math.floor(plotW / 10)))
    const prices  = visible.flatMap(c => [c.high, c.low])
    let minP = Math.min(...prices)
    let maxP = Math.max(...prices)
    const pad = (maxP - minP) * 0.08
    minP -= pad; maxP += pad
    const rangeP = maxP - minP || 1

    const maxVol = Math.max(...visible.map(c => c.volume)) || 1

    // Helpers
    const px = (i: number) => PADDING.left + (i / (visible.length - 1)) * plotW
    const py = (p: number) => PADDING.top  + ((maxP - p) / rangeP) * plotH
    const pxBar = (i: number) => PADDING.left + (i / visible.length) * plotW
    const barW  = (plotW / visible.length) * 0.7

    // ── Grid ────────────────────────────────────────────────────────────────
    ctx.strokeStyle = C.grid
    ctx.lineWidth   = 0.5
    const GRID_LINES = 5
    for (let i = 0; i <= GRID_LINES; i++) {
      const y = PADDING.top + (i / GRID_LINES) * plotH
      ctx.beginPath(); ctx.moveTo(PADDING.left, y); ctx.lineTo(W - PADDING.right, y); ctx.stroke()
      const price = maxP - (i / GRID_LINES) * rangeP
      ctx.fillStyle  = C.gridLabel
      ctx.font       = `10px "Geist Mono", monospace`
      ctx.textAlign  = "right"
      ctx.fillText(formatChartPrice(price), W - 4, y + 3.5)
    }

    // ── Volume bars ──────────────────────────────────────────────────────────
    visible.forEach((c, i) => {
      const x  = pxBar(i) + (plotW / visible.length) * 0.15
      const vh = (c.volume / maxVol) * (plotH * 0.18)
      ctx.fillStyle = c.close >= c.open ? "rgba(0,212,170,0.1)" : "rgba(246,70,93,0.1)"
      ctx.fillRect(x, H - PADDING.bottom - vh, barW, vh)
    })

    // ── Candles or line ───────────────────────────────────────────────────────
    if (chartType === "candle") {
      visible.forEach((c, i) => {
        const x    = pxBar(i) + (plotW / visible.length) * 0.15
        const bull = c.close >= c.open
        const col  = bull ? C.bull : C.bear

        // Wick
        ctx.strokeStyle = col
        ctx.lineWidth   = 1
        ctx.beginPath()
        ctx.moveTo(x + barW / 2, py(c.high))
        ctx.lineTo(x + barW / 2, py(c.low))
        ctx.stroke()

        // Body
        const bodyY = py(Math.max(c.open, c.close))
        const bodyH = Math.max(1.5, Math.abs(py(c.open) - py(c.close)))
        ctx.fillStyle = bull ? C.bullFill : C.bearFill
        ctx.strokeStyle = col
        ctx.lineWidth = 1
        ctx.beginPath()
        ctx.rect(x, bodyY, barW, bodyH)
        ctx.fill()
        ctx.stroke()
      })
    } else {
      // Line chart
      ctx.beginPath()
      visible.forEach((c, i) => {
        const x = px(i)
        const y = py(c.close)
        if (i === 0) ctx.moveTo(x, y)
        else ctx.lineTo(x, y)
      })
      ctx.strokeStyle = C.bull
      ctx.lineWidth   = 1.5
      ctx.stroke()

      // Area fill
      ctx.lineTo(px(visible.length - 1), PADDING.top + plotH)
      ctx.lineTo(px(0), PADDING.top + plotH)
      ctx.closePath()
      const grad = ctx.createLinearGradient(0, PADDING.top, 0, PADDING.top + plotH)
      grad.addColorStop(0, "rgba(0,212,170,0.18)")
      grad.addColorStop(1, "rgba(0,212,170,0)")
      ctx.fillStyle = grad
      ctx.fill()
    }

    // ── TWAP overlay ─────────────────────────────────────────────────────────
    if (twapPrice && twapPrice > minP && twapPrice < maxP) {
      const y = py(twapPrice)
      ctx.strokeStyle = C.twap
      ctx.lineWidth   = 1
      ctx.setLineDash([4, 3])
      ctx.beginPath(); ctx.moveTo(PADDING.left, y); ctx.lineTo(W - PADDING.right, y); ctx.stroke()
      ctx.setLineDash([])
      ctx.fillStyle  = C.twap
      ctx.font       = `9px "Geist Mono", monospace`
      ctx.textAlign  = "right"
      ctx.fillText(`TWAP ${formatChartPrice(twapPrice)}`, W - 4, y - 3)
    }

    // ── EMA overlay ──────────────────────────────────────────────────────────
    if (emaPrice && emaPrice > minP && emaPrice < maxP) {
      const y = py(emaPrice)
      ctx.strokeStyle = C.ema
      ctx.lineWidth   = 1
      ctx.setLineDash([2, 3])
      ctx.beginPath(); ctx.moveTo(PADDING.left, y); ctx.lineTo(W - PADDING.right, y); ctx.stroke()
      ctx.setLineDash([])
    }

    // ── Crosshair ────────────────────────────────────────────────────────────
    if (cursor) {
      ctx.strokeStyle = C.crosshair
      ctx.lineWidth   = 0.5
      ctx.setLineDash([3, 3])
      ctx.beginPath(); ctx.moveTo(cursor.x, PADDING.top); ctx.lineTo(cursor.x, PADDING.top + plotH); ctx.stroke()
      ctx.beginPath(); ctx.moveTo(PADDING.left, cursor.y); ctx.lineTo(W - PADDING.right, cursor.y); ctx.stroke()
      ctx.setLineDash([])
    }

    ctx.setTransform(1, 0, 0, 1, 0, 0)
  }, [candles, cursor, chartType, twapPrice, emaPrice])

  // ── Resize observer ───────────────────────────────────────────────────────
  useEffect(() => {
    const container = containerRef.current
    if (!container) return
    const ro = new ResizeObserver(entries => {
      const { width, height } = entries[0].contentRect
      const canvas = canvasRef.current
      if (!canvas) return
      const dpr = window.devicePixelRatio || 1
      dprRef.current = dpr
      canvas.width  = width  * dpr
      canvas.height = height * dpr
      canvas.style.width  = `${width}px`
      canvas.style.height = `${height}px`
      draw()
    })
    ro.observe(container)
    return () => ro.disconnect()
  }, [draw])

  useEffect(() => { draw() }, [draw])

  // ── Mouse move ───────────────────────────────────────────────────────────
  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current
    if (!canvas || candles.length < 2) return
    const rect  = canvas.getBoundingClientRect()
    const x     = e.clientX - rect.left
    const y     = e.clientY - rect.top
    const dpr   = dprRef.current
    const W     = canvas.width  / dpr
    const H     = canvas.height / dpr
    const plotW = W - PADDING.left - PADDING.right
    const plotH = H - PADDING.top  - PADDING.bottom
    const visible = candles.slice(-Math.max(60, Math.floor(plotW / 10)))

    // Snap to nearest candle
    const relX  = (x - PADDING.left) / plotW
    const idx   = Math.max(0, Math.min(visible.length - 1, Math.round(relX * (visible.length - 1))))
    setCursor({ x, y, candle: visible[idx] })
  }, [candles])

  const handleMouseLeave = () => setCursor(null)

  // Tooltip data
  const tc = cursor?.candle
  const isUp = tc ? tc.close >= tc.open : true

  return (
    <div className="flex flex-col h-full" style={{ background: "var(--bg-base)" }}>
      {/* Toolbar */}
      <div
        className="flex items-center justify-between px-3 h-8 shrink-0 border-b"
        style={{ borderColor: "var(--border-dim)" }}
      >
        {/* Timeframes */}
        <div className="flex items-center gap-0.5">
          {TIMEFRAMES.map(tf => (
            <button
              key={tf}
              onClick={() => onTimeframeChange(tf)}
              className={cn(
                "px-2 py-0.5 rounded font-mono text-[10px] transition-colors",
                timeframe === tf
                  ? "bg-[var(--teal-dim)] text-[var(--teal)]"
                  : "text-[var(--text-dim)] hover:text-[var(--text-secondary)]"
              )}
            >
              {tf}
            </button>
          ))}
        </div>

        {/* Chart type */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setChartType("candle")}
            className={cn(
              "p-1 rounded transition-colors",
              chartType === "candle" ? "text-[var(--teal)]" : "text-[var(--text-dim)] hover:text-[var(--text-secondary)]"
            )}
            title="Candlestick"
          >
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <rect x="3"  y="6"  width="4" height="12" rx="0.5" />
              <line x1="5"  y1="2"  x2="5"  y2="6"  />
              <line x1="5"  y1="18" x2="5"  y2="22" />
              <rect x="17" y="9"  width="4" height="8"  rx="0.5" />
              <line x1="19" y1="4"  x2="19" y2="9"  />
              <line x1="19" y1="17" x2="19" y2="20" />
              <rect x="10" y="7"  width="4" height="10" rx="0.5" />
              <line x1="12" y1="3"  x2="12" y2="7"  />
              <line x1="12" y1="17" x2="12" y2="21" />
            </svg>
          </button>
          <button
            onClick={() => setChartType("line")}
            className={cn(
              "p-1 rounded transition-colors",
              chartType === "line" ? "text-[var(--teal)]" : "text-[var(--text-dim)] hover:text-[var(--text-secondary)]"
            )}
            title="Line"
          >
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
            </svg>
          </button>
        </div>

        {/* OHLCV tooltip */}
        {tc && (
          <div className="flex items-center gap-3 font-mono text-[10px]">
            <span style={{ color: "var(--text-dim)" }}>{new Date(tc.time).toLocaleString()}</span>
            <span style={{ color: "var(--text-secondary)" }}>O <span style={{ color: isUp ? "var(--teal)" : "var(--red)" }}>{formatChartPrice(tc.open)}</span></span>
            <span style={{ color: "var(--text-secondary)" }}>H <span style={{ color: "var(--teal)" }}>{formatChartPrice(tc.high)}</span></span>
            <span style={{ color: "var(--text-secondary)" }}>L <span style={{ color: "var(--red)"  }}>{formatChartPrice(tc.low) }</span></span>
            <span style={{ color: "var(--text-secondary)" }}>C <span style={{ color: isUp ? "var(--teal)" : "var(--red)" }}>{formatChartPrice(tc.close)}</span></span>
          </div>
        )}
      </div>

      {/* Canvas */}
      <div ref={containerRef} className="flex-1 relative chart-container">
        {isLoading && candles.length === 0 ? (
          <ChartSkeleton />
        ) : candles.length < 2 ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-2">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="var(--text-faint)" strokeWidth="1">
              <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
            </svg>
            <span className="font-mono text-xs" style={{ color: "var(--text-faint)" }}>
              No chart data available
            </span>
            <span className="font-mono text-[10px]" style={{ color: "var(--text-faint)" }}>
              Data appears once token starts trading
            </span>
          </div>
        ) : (
          <canvas
            ref={canvasRef}
            style={{ display: "block", width: "100%", height: "100%" }}
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
          />
        )}
      </div>
    </div>
  )
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function formatChartPrice(p: number): string {
  if (!p || !isFinite(p)) return "—"
  if (p >= 1000)   return p.toLocaleString("en-US", { maximumFractionDigits: 2 })
  if (p >= 1)      return p.toFixed(4)
  if (p >= 0.001)  return p.toFixed(6)
  return p.toExponential(3)
}

function ChartSkeleton() {
  return (
    <div className="absolute inset-0 flex items-end gap-0.5 px-4 pb-8 pt-6 opacity-20">
      {Array.from({ length: 60 }).map((_, i) => {
        const h = 20 + Math.sin(i * 0.4) * 30 + Math.random() * 20
        return (
          <div
            key={i}
            className="flex-1 rounded-sm animate-pulse"
            style={{ height: `${h}%`, background: "var(--border-std)" }}
          />
        )
      })}
    </div>
  )
}
